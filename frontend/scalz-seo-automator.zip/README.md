# Scalz SEO Automator

**Version:** 1.0.0  
**Requires WordPress:** 5.8+  
**Requires PHP:** 7.4+  
**Author:** [Scalz AI](https://scalz.ai)  
**License:** GPL-2.0-or-later

---

## Overview

Scalz SEO Automator is a WordPress companion plugin for the [Scalz AI](https://scalz.ai) central dashboard. It exposes a secure REST API that the dashboard calls to automate SEO tasks across client WordPress sites — including meta descriptions, ACF content generation, blog creation, alt tag optimization, FAQ schema, and more.

---

## Installation

1. Upload the `scalz-seo-automator/` folder to `/wp-content/plugins/`.
2. Activate the plugin from **Plugins > Installed Plugins**.
3. Go to **Settings > Scalz SEO Automator** to copy your API key.
4. Paste the API key into the Scalz dashboard for this site.

---

## Configuration

All configuration is done via **Settings > Scalz SEO Automator** in the WordPress admin.

### API Key
A 32-character API key is auto-generated on activation. Copy it and enter it in the Scalz dashboard. You can regenerate it at any time — remember to update the dashboard when you do.

### AI Provider
Choose between:
- **OpenAI (Direct API)** — Provide your OpenAI API key. Supports GPT-4o, GPT-4o Mini, GPT-4 Turbo, GPT-3.5 Turbo.
- **AI Engine by Meow Apps** — Uses the installed AI Engine plugin. No separate API key needed (AI Engine manages its own).

### Prompt Templates
Each automation type has a master prompt template stored in WordPress options. Variables like `{title}`, `{location}`, `{service}` are replaced at runtime by the dashboard.

---

## Authentication

Every REST API request must include the header:

```
X-Scalz-API-Key: your-api-key-here
```

Requests without a valid key receive `401 Unauthorized`.

---

## REST API Reference

**Base URL:** `https://yoursite.com/wp-json/scalz/v1/`

---

### `GET /status`
Health check. Returns plugin version and active integrations.

**Response:**
```json
{
  "status": "ok",
  "version": "1.0.0",
  "integrations": {
    "rankmath": true,
    "acf": true,
    "link_whisper": false,
    "ai_engine": false,
    "openai": true
  },
  "timestamp": "2026-02-27T10:41:00-05:00"
}
```

---

### `GET /site-info`
Returns site metadata for the dashboard overview panel.

**Response:**
```json
{
  "site_title": "My Business",
  "site_url": "https://mybusiness.com",
  "wp_version": "6.7",
  "php_version": "8.2.0",
  "active_theme": { "name": "GeneratePress", "version": "3.4.0" },
  "active_plugins": ["advanced-custom-fields/acf.php", "seo-by-rank-math/rank-math.php"],
  "plugin_version": "1.0.0"
}
```

---

### `POST /plugins/install`
Download, install, and activate a plugin from a `.zip` URL.

**Request Body:**
```json
{
  "plugin_file_url": "https://example.com/my-plugin.zip",
  "license_key": "XXXX-XXXX-XXXX-XXXX"
}
```

**Response:**
```json
{
  "success": true,
  "plugin_file": "my-plugin/my-plugin.php",
  "activated": true,
  "license_activated": true,
  "license_message": "EDD license activated successfully."
}
```

License activation supports: EDD Software Licensing, Freemius, and a generic options-based fallback.

---

### `POST /pages/update-titles`
Bulk update WordPress page/post titles.

**Request Body:**
```json
{
  "pages": [
    { "page_id": 42, "new_title": "HVAC Repair in Austin, TX" },
    { "page_id": 55, "new_title": "AC Installation in Austin, TX" }
  ]
}
```

**Response:**
```json
{
  "updated": [
    { "page_id": 42, "new_title": "HVAC Repair in Austin, TX" }
  ],
  "failed": []
}
```

---

### `POST /seo/meta-descriptions`
Set meta descriptions for pages/posts via RankMath (and Yoast as fallback).

**Manual mode:**
```json
{
  "pages": [
    { "page_id": 42, "meta_description": "Expert HVAC repair in Austin, TX. Call today for fast service." }
  ]
}
```

**Auto-generate mode** (uses AI + stored prompt template):
```json
{
  "auto_generate": true,
  "ai_config": { "model": "gpt-4o" }
}
```

---

### `POST /content/acf-update`
Update an ACF field with pre-written content.

**Request Body:**
```json
{
  "page_id": 42,
  "field_name": "page_content_section",
  "content": "<h2>Why Choose Us?</h2><p>15 years of experience...</p>",
  "field_type": "wysiwyg"
}
```

Falls back to `update_post_meta()` if ACF is not installed.

---

### `POST /content/generate`
Generate AI content from a prompt template and save it to an ACF field.

**Request Body:**
```json
{
  "page_id": 42,
  "field_name": "page_content_section",
  "prompt_template": "Write SEO content for a {service} company in {city}, {state}. Business: {business_name}.",
  "variables": {
    "service": "HVAC Repair",
    "city": "Austin",
    "state": "Texas",
    "business_name": "Cool Breeze HVAC"
  }
}
```

The post title, existing content, and RankMath focus keyword are automatically included in the variable pool.

---

### `POST /seo/alt-tags`
Scan pages/posts for images missing alt tags and generate them with AI.

**Request Body:**
```json
{ "page_id": 42 }
```

Omit `page_id` to process all published posts and pages. Updates both featured image attachment meta and inline `<img alt="">` attributes in post content.

---

### `POST /linking/run`
Trigger LinkWhisper's internal linking engine.

**Request Body:**
```json
{ "post_ids": [42, 55, 67] }
```

Omit `post_ids` to run on all published posts and pages. Requires LinkWhisper to be installed and active.

---

### `GET /sitemap/posts`
Fetch and parse `/post-sitemap.xml`. Returns all post titles and URLs for duplicate detection.

**Response:**
```json
{
  "count": 47,
  "posts": [
    { "title": "How to Choose an HVAC System", "url": "https://site.com/how-to-choose-hvac/" }
  ]
}
```

Falls back to a WordPress database query if the sitemap is unavailable.

---

### `POST /blogs/generate-titles`
Generate unique blog title ideas with AI.

**Request Body:**
```json
{
  "count": 10,
  "niche": "HVAC",
  "location": "Austin, Texas",
  "existing_titles": ["How to Choose an HVAC System", "HVAC Maintenance Tips"]
}
```

**Response:**
```json
{
  "count": 10,
  "titles": [
    "5 Signs Your Austin Home Needs Emergency AC Repair",
    "Heat Pump vs. Central Air: What Austin Homeowners Need to Know"
  ]
}
```

---

### `POST /blogs/create`
Create a new WordPress blog post.

**Request Body:**
```json
{
  "title": "5 Signs Your Austin Home Needs Emergency AC Repair",
  "content": "<p>When the Texas heat...</p><h2>Sign 1: Warm Air</h2>...",
  "categories": ["HVAC Tips", "Austin"],
  "tags": ["air conditioning", "emergency repair"]
}
```

All H3–H6 headings are automatically converted to H2 before saving.

**Response:**
```json
{
  "success": true,
  "post_id": 123,
  "title": "5 Signs Your Austin Home Needs Emergency AC Repair",
  "permalink": "https://site.com/5-signs-austin-home-ac-repair/"
}
```

---

### `POST /blogs/fix-headings`
Convert all H3–H6 headings in an existing post to H2.

**Request Body:**
```json
{ "post_id": 123 }
```

---

### `POST /schema/faq`
Generate FAQ schema (JSON-LD) and inject it into a post.

**Request Body:**
```json
{
  "post_id": 42,
  "faqs": [
    { "question": "How long does AC repair take?", "answer": "Most repairs take 1–3 hours." },
    { "question": "Do you offer emergency service?", "answer": "Yes, we offer 24/7 emergency HVAC service in Austin." }
  ]
}
```

If RankMath is active, the schema is injected via RankMath's schema meta fields. Otherwise, it's stored in post meta and output via `wp_head`.

---

### `POST /ai/configure`
Update AI provider settings from the dashboard.

**Request Body:**
```json
{
  "provider": "openai",
  "api_key": "sk-...",
  "model": "gpt-4o",
  "temperature": 0.7
}
```

---

### `POST /rankmath/optimize`
Set RankMath focus keyword and retrieve the SEO score.

**Request Body:**
```json
{
  "post_id": 42,
  "focus_keyword": "HVAC repair Austin TX"
}
```

**Response:**
```json
{
  "success": true,
  "post_id": 42,
  "focus_keyword": "HVAC repair Austin TX",
  "seo_score": 82,
  "rankmath_active": true
}
```

---

## Template Variable Reference

| Variable | Description |
|---|---|
| `{title}` | Page/post title |
| `{location}` | Full location (City, State) |
| `{city}` | City name |
| `{state}` | Full state name |
| `{state_abbr}` | State abbreviation |
| `{business_name}` | Business/site name |
| `{service}` | Service name |
| `{niche}` | Business niche/industry |
| `{phone}` | Business phone number |
| `{address}` | Business address |
| `{existing_content}` | Current page content (stripped HTML) |
| `{focus_keyword}` | Target SEO keyword (from RankMath) |
| `{count}` | Number of items to generate |
| `{existing_titles}` | Pipe-separated list of existing titles |

---

## Third-Party Integrations

| Plugin | Required | Notes |
|---|---|---|
| RankMath SEO | Recommended | Meta descriptions and focus keywords use RankMath post meta. Falls back to Yoast meta keys. |
| Advanced Custom Fields | Optional | Required for `/content/acf-update` and `/content/generate`. Falls back to `update_post_meta`. |
| LinkWhisper | Optional | Required for `/linking/run`. |
| AI Engine (Meow Apps) | Optional | Alternative AI provider to OpenAI. |
| OpenAI | Recommended | Direct API used when provider is set to "openai". |

---

## File Structure

```
scalz-seo-automator/
├── scalz-seo-automator.php          ← Main plugin file, bootstrap, hooks
├── includes/
│   ├── class-api-endpoints.php      ← REST route registration + dispatch
│   ├── class-seo-manager.php        ← Page titles, meta descriptions, alt tags
│   ├── class-content-manager.php    ← ACF updates + AI content generation
│   ├── class-blog-manager.php       ← Sitemap parsing, blog titles, creation
│   ├── class-integration-manager.php ← OpenAI, AI Engine, RankMath, LinkWhisper
│   ├── class-schema-manager.php     ← FAQ JSON-LD schema injection
│   ├── class-plugin-installer.php   ← Plugin download, install, license
│   └── class-settings.php          ← Admin page registration + option handling
├── admin/
│   ├── settings-page.php            ← Admin UI template
│   └── admin.css                    ← Admin styles
└── README.md
```

---

## Security

- All endpoints require `X-Scalz-API-Key` header authentication using `hash_equals()` (timing-safe comparison).
- Settings page uses WordPress nonces for all form submissions.
- All REST input is sanitized (`sanitize_text_field`, `wp_kses_post`, `esc_url_raw`, etc.).
- Admin page checks `current_user_can('manage_options')` before rendering or processing.
- Uninstall hook removes all stored options from the database.

---

## Changelog

### 1.0.0
- Initial release.
- 16 REST API endpoints covering SEO, content, blogs, schema, and integrations.
- OpenAI and AI Engine support.
- RankMath and Yoast meta description compatibility.
- ACF field updates with fallback to post meta.
- FAQ schema via RankMath schema API or standalone JSON-LD injection.
- EDD / Freemius license activation support.
- Full admin settings page with prompt template management.

---

## Support

For issues or questions, contact [tim@scalz.ai](mailto:tim@scalz.ai) or visit [scalz.ai](https://scalz.ai).
