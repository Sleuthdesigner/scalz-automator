<?php
/**
 * Internal Linking Engine
 *
 * A complete internal linking system that replaces LinkWhisper.
 * Handles link suggestion, insertion, reporting, and orphan detection.
 *
 * @package ScalzSEOAutomator
 * @since   1.1.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Scalz_Internal_Linker {

	/**
	 * Default configuration for the linker.
	 */
	private array $config = [
		'max_links_per_post'       => 10,
		'max_links_per_sentence'   => 1,
		'min_content_length'       => 100,     // Min chars in post to process
		'min_anchor_length'        => 3,       // Min words in anchor text
		'max_anchor_length'        => 8,       // Max words in anchor text
		'skip_first_paragraph'     => true,    // Don't link in first paragraph
		'open_in_new_tab'          => false,
		'nofollow'                 => false,
		'exclude_categories'       => [],
		'exclude_post_types'       => [ 'attachment', 'revision', 'nav_menu_item' ],
		'link_to_self'             => false,
		'case_sensitive'           => false,
		'respect_existing_links'   => true,    // Don't add links where one already exists in sentence
		'prioritize_focus_keyword' => true,    // Prefer RankMath/Yoast focus keywords
	];

	/**
	 * Constructor — merges saved options with defaults.
	 */
	public function __construct() {
		$saved = get_option( 'scalz_internal_linker_config', [] );
		if ( is_array( $saved ) && ! empty( $saved ) ) {
			$this->config = array_merge( $this->config, $saved );
		}
	}

	/**
	 * Save configuration to wp_options.
	 *
	 * @param array $new_config New configuration values to merge.
	 * @return array Updated configuration.
	 */
	public function update_config( array $new_config ): array {
		$this->config = array_merge( $this->config, $new_config );
		update_option( 'scalz_internal_linker_config', $this->config );
		return $this->config;
	}

	/**
	 * Get current configuration.
	 *
	 * @return array Current configuration.
	 */
	public function get_config(): array {
		return $this->config;
	}

	// ====================================================================
	// LINK INDEX — Build a keyword-to-post mapping for the entire site
	// ====================================================================

	/**
	 * Build or rebuild the link index.
	 *
	 * Creates a mapping of keywords/phrases to post IDs.
	 * Sources: post titles, RankMath/Yoast focus keywords,
	 * custom target keywords, H2 headings.
	 *
	 * @param bool $force_rebuild Whether to rebuild from scratch.
	 * @return array Stats about the index.
	 */
	public function build_link_index( bool $force_rebuild = false ): array {
		$index = [];
		$stats = [
			'posts_indexed'  => 0,
			'keywords_total' => 0,
		];

		// Get all published posts and pages.
		$post_types = get_post_types( [ 'public' => true ], 'names' );
		$post_types = array_diff( $post_types, $this->config['exclude_post_types'] );

		$posts = get_posts( [
			'post_type'      => array_values( $post_types ),
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
		] );

		foreach ( $posts as $post_id ) {
			$post = get_post( $post_id );
			if ( ! $post ) {
				continue;
			}

			$keywords  = $this->extract_keywords_for_post( $post );
			$permalink = get_permalink( $post_id );

			foreach ( $keywords as $keyword ) {
				$normalized = $this->normalize_keyword( $keyword );
				if ( strlen( $normalized ) < 3 ) {
					continue;
				}

				$index[ $normalized ] = [
					'post_id'   => $post_id,
					'url'       => $permalink,
					'title'     => $post->post_title,
					'keyword'   => $keyword,
					'post_type' => $post->post_type,
				];
				$stats['keywords_total']++;
			}
			$stats['posts_indexed']++;
		}

		// Store the index in a transient (expires in 24 hours, or rebuild on demand).
		set_transient( 'scalz_link_index', $index, DAY_IN_SECONDS );
		update_option( 'scalz_link_index_stats', $stats );

		return $stats;
	}

	/**
	 * Get the link index (build if missing).
	 *
	 * @return array The link index.
	 */
	private function get_link_index(): array {
		$index = get_transient( 'scalz_link_index' );
		if ( false === $index ) {
			$this->build_link_index();
			$index = get_transient( 'scalz_link_index' );
		}
		return is_array( $index ) ? $index : [];
	}

	/**
	 * Extract linkable keywords from a post.
	 *
	 * Sources (in priority order):
	 * 1. RankMath focus keyword
	 * 2. Yoast focus keyword
	 * 3. Custom target keywords (stored in scalz_target_keywords meta)
	 * 4. Post title and title variations
	 * 5. H2 headings in content
	 *
	 * @param WP_Post $post The post object.
	 * @return array Array of keyword strings.
	 */
	private function extract_keywords_for_post( WP_Post $post ): array {
		$keywords = [];

		// 1. RankMath focus keyword.
		$rm_keyword = get_post_meta( $post->ID, 'rank_math_focus_keyword', true );
		if ( $rm_keyword ) {
			// RankMath can store multiple keywords comma-separated.
			$rm_keywords = array_map( 'trim', explode( ',', $rm_keyword ) );
			$keywords    = array_merge( $keywords, $rm_keywords );
		}

		// 2. Yoast focus keyword.
		$yoast_keyword = get_post_meta( $post->ID, '_yoast_wpseo_focuskw', true );
		if ( $yoast_keyword ) {
			$keywords[] = $yoast_keyword;
		}

		// 3. Custom target keywords.
		$custom = get_post_meta( $post->ID, 'scalz_target_keywords', true );
		if ( $custom ) {
			$custom_keywords = array_map( 'trim', explode( ',', $custom ) );
			$keywords        = array_merge( $keywords, $custom_keywords );
		}

		// 4. Post title and variations.
		$title      = $post->post_title;
		$keywords[] = $title;

		// Generate title variations (remove common suffixes like "| Brand Name").
		$title_clean = preg_replace( '/\s*[\|\-–—]\s*.+$/', '', $title );
		if ( $title_clean !== $title && strlen( $title_clean ) > 10 ) {
			$keywords[] = $title_clean;
		}

		// 5. H2 headings.
		if ( ! empty( $post->post_content ) ) {
			preg_match_all( '/<h2[^>]*>(.*?)<\/h2>/i', $post->post_content, $h2_matches );
			if ( ! empty( $h2_matches[1] ) ) {
				foreach ( $h2_matches[1] as $h2 ) {
					$h2_text = strip_tags( $h2 );
					if ( strlen( $h2_text ) > 10 && strlen( $h2_text ) < 80 ) {
						$keywords[] = $h2_text;
					}
				}
			}
		}

		// Deduplicate and filter empty values.
		$keywords = array_unique( array_filter( $keywords ) );
		return $keywords;
	}

	/**
	 * Normalize a keyword for matching.
	 *
	 * @param string $keyword The keyword to normalize.
	 * @return string Normalized keyword.
	 */
	private function normalize_keyword( string $keyword ): string {
		$keyword = strip_tags( $keyword );
		$keyword = html_entity_decode( $keyword, ENT_QUOTES, 'UTF-8' );
		if ( ! $this->config['case_sensitive'] ) {
			$keyword = mb_strtolower( $keyword );
		}
		$keyword = preg_replace( '/\s+/', ' ', trim( $keyword ) );
		return $keyword;
	}

	// ====================================================================
	// LINK SUGGESTIONS — Find opportunities for a given post
	// ====================================================================

	/**
	 * Get link suggestions for a specific post.
	 *
	 * Scans the post content and finds sentences where keywords from
	 * other posts appear naturally. Returns suggestions with context.
	 *
	 * @param int $post_id The post to analyze.
	 * @return array Array of suggestions.
	 */
	public function get_suggestions( int $post_id ): array {
		$post = get_post( $post_id );
		if ( ! $post || empty( $post->post_content ) ) {
			return [];
		}

		$index       = $this->get_link_index();
		$content     = $post->post_content;
		$suggestions = [];
		$linked_urls = $this->get_existing_links( $content );
		$sentences   = $this->split_into_sentences( strip_tags( $content ) );

		// Track how many links we've suggested per sentence.
		$sentence_link_count = [];

		foreach ( $index as $normalized => $target ) {
			// Don't link to self.
			if ( ! $this->config['link_to_self'] && $target['post_id'] === $post_id ) {
				continue;
			}

			// Skip if we already link to this URL.
			if ( $this->config['respect_existing_links'] && in_array( $target['url'], $linked_urls, true ) ) {
				continue;
			}

			// Find keyword in content sentences.
			foreach ( $sentences as $i => $sentence ) {
				// Skip first paragraph if configured.
				if ( $this->config['skip_first_paragraph'] && $i < 2 ) {
					continue;
				}

				// Check sentence link limit.
				$si = (string) $i;
				if ( isset( $sentence_link_count[ $si ] ) && $sentence_link_count[ $si ] >= $this->config['max_links_per_sentence'] ) {
					continue;
				}

				// Check if keyword appears in this sentence.
				$sentence_normalized = $this->normalize_keyword( $sentence );
				$pos                 = mb_strpos( $sentence_normalized, $normalized );

				if ( false !== $pos ) {
					// Check if this part of the sentence already has a link.
					if ( $this->sentence_has_link_at_position( $content, $sentence, $pos ) ) {
						continue;
					}

					// Extract the actual anchor text (preserving original case).
					$anchor = mb_substr( $sentence, $pos, mb_strlen( $normalized ) );

					// Validate anchor length.
					$word_count = str_word_count( $anchor );
					if ( $word_count < $this->config['min_anchor_length'] && $word_count > 0 ) {
						// Try to expand anchor to include surrounding words.
						$anchor = $this->expand_anchor( $sentence, $pos, mb_strlen( $normalized ) );
					}

					$suggestions[] = [
						'target_post_id' => $target['post_id'],
						'target_url'     => $target['url'],
						'target_title'   => $target['title'],
						'keyword'        => $target['keyword'],
						'anchor_text'    => $anchor,
						'sentence'       => trim( $sentence ),
						'sentence_index' => $i,
						'score'          => $this->calculate_relevance_score( $post, $target, $anchor ),
					];

					if ( ! isset( $sentence_link_count[ $si ] ) ) {
						$sentence_link_count[ $si ] = 0;
					}
					$sentence_link_count[ $si ]++;

					// Only one suggestion per target post per source post.
					break;
				}
			}

			// Stop if we have enough suggestions.
			if ( count( $suggestions ) >= $this->config['max_links_per_post'] * 2 ) {
				break;
			}
		}

		// Sort by relevance score (highest first).
		usort( $suggestions, function ( $a, $b ) {
			return $b['score'] <=> $a['score'];
		} );

		// Limit to max_links_per_post * 2 (returns double for caller to choose).
		return array_slice( $suggestions, 0, $this->config['max_links_per_post'] * 2 );
	}

	/**
	 * Calculate relevance score for a suggestion.
	 * Higher score = more relevant.
	 *
	 * @param WP_Post $source The source post object.
	 * @param array   $target Target post data from the index.
	 * @param string  $anchor The anchor text for the link.
	 * @return float Score between 0 and 100.
	 */
	private function calculate_relevance_score( WP_Post $source, array $target, string $anchor ): float {
		$score = 50.0; // Base score.

		// Bonus for focus keyword match.
		$rm_kw    = get_post_meta( $target['post_id'], 'rank_math_focus_keyword', true );
		$yoast_kw = get_post_meta( $target['post_id'], '_yoast_wpseo_focuskw', true );
		$focus    = $rm_kw ?: $yoast_kw;
		if ( $focus && stripos( $anchor, $focus ) !== false ) {
			$score += 30;
		}

		// Bonus for same category.
		$source_cats = wp_get_post_categories( $source->ID, [ 'fields' => 'ids' ] );
		$target_cats = wp_get_post_categories( $target['post_id'], [ 'fields' => 'ids' ] );
		if ( ! empty( array_intersect( $source_cats, $target_cats ) ) ) {
			$score += 20;
		}

		// Bonus for same post type.
		if ( $source->post_type === $target['post_type'] ) {
			$score += 5;
		}

		// Penalty for very short or very long anchors.
		$word_count = str_word_count( $anchor );
		if ( $word_count < 2 ) {
			$score -= 15;
		}
		if ( $word_count > 6 ) {
			$score -= 5;
		}

		// Bonus for anchor length in sweet spot (3–5 words).
		if ( $word_count >= 3 && $word_count <= 5 ) {
			$score += 10;
		}

		return max( 0, min( 100, $score ) );
	}

	// ====================================================================
	// LINK INSERTION — Apply links to post content
	// ====================================================================

	/**
	 * Auto-insert internal links into a post.
	 *
	 * @param int   $post_id     The post to add links to.
	 * @param array $suggestions Optional specific suggestions to apply. If empty, generates them.
	 * @param int   $max_links   Maximum links to insert. 0 = use config default.
	 * @return array Results with links inserted.
	 */
	public function insert_links( int $post_id, array $suggestions = [], int $max_links = 0 ): array {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return [ 'error' => 'Post not found', 'links_inserted' => 0 ];
		}

		if ( empty( $suggestions ) ) {
			$suggestions = $this->get_suggestions( $post_id );
		}

		$max     = $max_links > 0 ? $max_links : $this->config['max_links_per_post'];
		$content = $post->post_content;
		$inserted = [];
		$count    = 0;

		// Sort by score descending.
		usort( $suggestions, function ( $a, $b ) {
			return $b['score'] <=> $a['score'];
		} );

		foreach ( $suggestions as $suggestion ) {
			if ( $count >= $max ) {
				break;
			}

			$anchor = $suggestion['anchor_text'];
			$url    = $suggestion['target_url'];

			// Build link attributes.
			$attrs = '';
			if ( $this->config['open_in_new_tab'] ) {
				$attrs .= ' target="_blank" rel="noopener noreferrer"';
			}
			if ( $this->config['nofollow'] ) {
				$attrs .= ' rel="nofollow"';
			}

			$link_html = '<a href="' . esc_url( $url ) . '"' . $attrs . '>' . esc_html( $anchor ) . '</a>';

			// Find and replace the FIRST occurrence of the anchor not already in a link.
			$new_content = $this->safe_replace_anchor( $content, $anchor, $link_html );

			if ( $new_content !== $content ) {
				$content    = $new_content;
				$inserted[] = [
					'anchor'       => $anchor,
					'url'          => $url,
					'target_title' => $suggestion['target_title'],
					'score'        => $suggestion['score'],
				];
				$count++;
			}
		}

		// Update post content if any links were inserted.
		if ( ! empty( $inserted ) ) {
			wp_update_post( [
				'ID'           => $post_id,
				'post_content' => $content,
			] );
		}

		return [
			'post_id'        => $post_id,
			'links_inserted' => count( $inserted ),
			'links'          => $inserted,
		];
	}

	/**
	 * Safely replace an anchor text with a link in content.
	 *
	 * Avoids replacing text that's already inside an <a> tag, heading, or shortcode.
	 * Splits content into tag and text nodes, only replacing in text nodes.
	 *
	 * @param string $content   The post content.
	 * @param string $anchor    The anchor text to find.
	 * @param string $link_html The full <a> HTML to insert.
	 * @return string Modified content, or original if no replacement was made.
	 */
	private function safe_replace_anchor( string $content, string $anchor, string $link_html ): string {
		// Escape anchor for regex use.
		$escaped = preg_quote( $anchor, '/' );
		$flags   = $this->config['case_sensitive'] ? '' : 'i';

		// Split content into interleaved text nodes and HTML tags.
		$parts      = preg_split( '/(<[^>]+>)/', $content, -1, PREG_SPLIT_DELIM_CAPTURE );
		$in_link    = 0;
		$in_heading = 0;
		$replaced   = false;

		foreach ( $parts as &$part ) {
			// Track opening <a> tags.
			if ( preg_match( '/<a[\s>]/i', $part ) ) {
				$in_link++;
				continue;
			}
			// Track closing </a> tags.
			if ( preg_match( '/<\/a>/i', $part ) ) {
				$in_link = max( 0, $in_link - 1 );
				continue;
			}
			// Track opening heading tags (h1–h6).
			if ( preg_match( '/<h[1-6][\s>]/i', $part ) ) {
				$in_heading++;
				continue;
			}
			// Track closing heading tags.
			if ( preg_match( '/<\/h[1-6]>/i', $part ) ) {
				$in_heading = max( 0, $in_heading - 1 );
				continue;
			}
			// Skip any other HTML tag.
			if ( strpos( $part, '<' ) === 0 ) {
				continue;
			}
			// Skip text nodes that are inside a link or heading.
			if ( $in_link > 0 || $in_heading > 0 ) {
				continue;
			}

			// Attempt replacement in this text node (first occurrence only).
			if ( ! $replaced ) {
				$new_part = preg_replace(
					'/\b' . $escaped . '\b/' . $flags,
					$link_html,
					$part,
					1,
					$match_count
				);
				if ( $match_count > 0 ) {
					$part     = $new_part;
					$replaced = true;
				}
			}
		}
		unset( $part );

		return $replaced ? implode( '', $parts ) : $content;
	}

	// ====================================================================
	// BULK OPERATIONS
	// ====================================================================

	/**
	 * Run internal linking on all posts of given types.
	 *
	 * Rebuilds the link index first, then processes each post.
	 *
	 * @param array $post_types Post types to process.
	 * @param int   $max_links  Max links per post. 0 = use config default.
	 * @return array Summary of all operations.
	 */
	public function run_bulk_linking( array $post_types = [ 'post', 'page' ], int $max_links = 0 ): array {
		// Rebuild index first to ensure freshness.
		$this->build_link_index( true );

		$posts = get_posts( [
			'post_type'      => $post_types,
			'post_status'    => 'publish',
			'posts_per_page' => -1,
			'fields'         => 'ids',
		] );

		$results = [
			'posts_processed'      => 0,
			'total_links_inserted' => 0,
			'details'              => [],
		];

		foreach ( $posts as $post_id ) {
			$result = $this->insert_links( $post_id, [], $max_links );
			$results['posts_processed']++;
			$results['total_links_inserted'] += $result['links_inserted'];
			if ( $result['links_inserted'] > 0 ) {
				$results['details'][] = $result;
			}
		}

		return $results;
	}

	/**
	 * Create auto-link rules (keyword → URL pairs).
	 *
	 * These are persistent rules stored in wp_options that can be applied
	 * programmatically to any post at any time.
	 *
	 * @param array $rules Array of rule definitions, each with 'keyword', 'url', and optional 'options'.
	 * @return array All stored rules after insertion.
	 */
	public function create_autolink_rules( array $rules ): array {
		$existing = get_option( 'scalz_autolink_rules', [] );

		foreach ( $rules as $rule ) {
			if ( empty( $rule['keyword'] ) || empty( $rule['url'] ) ) {
				continue;
			}

			$existing[] = [
				'keyword'      => sanitize_text_field( $rule['keyword'] ),
				'url'          => esc_url_raw( $rule['url'] ),
				'max_per_post' => intval( $rule['options']['max_per_post'] ?? 1 ),
				'nofollow'     => ! empty( $rule['options']['nofollow'] ),
				'new_tab'      => ! empty( $rule['options']['new_tab'] ),
				'active'       => true,
				'created_at'   => current_time( 'mysql' ),
			];
		}

		update_option( 'scalz_autolink_rules', $existing );
		return $existing;
	}

	/**
	 * Get all auto-link rules.
	 *
	 * @return array All stored auto-link rules.
	 */
	public function get_autolink_rules(): array {
		return get_option( 'scalz_autolink_rules', [] );
	}

	/**
	 * Delete an auto-link rule by its array index.
	 *
	 * @param int $index Zero-based index of the rule to delete.
	 * @return array Remaining rules after deletion.
	 */
	public function delete_autolink_rule( int $index ): array {
		$rules = get_option( 'scalz_autolink_rules', [] );
		if ( isset( $rules[ $index ] ) ) {
			array_splice( $rules, $index, 1 );
			update_option( 'scalz_autolink_rules', $rules );
		}
		return $rules;
	}

	/**
	 * Apply all active auto-link rules to a post.
	 *
	 * Each active rule's keyword is linked to its target URL in the post content.
	 * Respects the max_per_post setting for each rule.
	 *
	 * @param int $post_id The post to apply rules to.
	 * @return array Results including links inserted.
	 */
	public function apply_autolink_rules( int $post_id ): array {
		$rules = $this->get_autolink_rules();
		$post  = get_post( $post_id );

		if ( ! $post || empty( $rules ) ) {
			return [ 'links_inserted' => 0 ];
		}

		$content  = $post->post_content;
		$inserted = [];

		foreach ( $rules as $rule ) {
			if ( empty( $rule['active'] ) ) {
				continue;
			}

			// Build link attributes.
			$attrs = '';
			if ( ! empty( $rule['new_tab'] ) ) {
				$attrs .= ' target="_blank" rel="noopener noreferrer"';
			}
			if ( ! empty( $rule['nofollow'] ) ) {
				$attrs .= ' rel="nofollow"';
			}

			$link_html = '<a href="' . esc_url( $rule['url'] ) . '"' . $attrs . '>' . esc_html( $rule['keyword'] ) . '</a>';

			$max = $rule['max_per_post'] ?? 1;
			for ( $i = 0; $i < $max; $i++ ) {
				$new_content = $this->safe_replace_anchor( $content, $rule['keyword'], $link_html );
				if ( $new_content !== $content ) {
					$content    = $new_content;
					$inserted[] = [
						'keyword' => $rule['keyword'],
						'url'     => $rule['url'],
					];
				} else {
					// No more occurrences found; stop iterating this rule.
					break;
				}
			}
		}

		if ( ! empty( $inserted ) ) {
			wp_update_post( [
				'ID'           => $post_id,
				'post_content' => $content,
			] );
		}

		return [
			'post_id'        => $post_id,
			'links_inserted' => count( $inserted ),
			'links'          => $inserted,
		];
	}

	// ====================================================================
	// REPORTING
	// ====================================================================

	/**
	 * Get internal link report for the entire site.
	 *
	 * Returns a per-post breakdown of inbound internal links, outbound
	 * internal links, external links, and orphan status. Orphans and
	 * low-inbound posts are sorted to the top.
	 *
	 * @return array Report data including totals and per-post details.
	 */
	public function get_link_report(): array {
		$posts = get_posts( [
			'post_type'      => [ 'post', 'page' ],
			'post_status'    => 'publish',
			'posts_per_page' => -1,
		] );

		$report = [];

		foreach ( $posts as $post ) {
			$content  = $post->post_content;
			$inbound  = $this->count_inbound_links( $post->ID );
			$outbound = $this->count_outbound_links( $content );
			$external = $this->count_external_links( $content );

			$report[] = [
				'post_id'           => $post->ID,
				'title'             => $post->post_title,
				'url'               => get_permalink( $post->ID ),
				'post_type'         => $post->post_type,
				'inbound_internal'  => $inbound,
				'outbound_internal' => $outbound,
				'external'          => $external,
				'is_orphan'         => ( 0 === $inbound ),
			];
		}

		// Sort: orphans first, then by fewest inbound links.
		usort( $report, function ( $a, $b ) {
			if ( $a['is_orphan'] !== $b['is_orphan'] ) {
				return $b['is_orphan'] <=> $a['is_orphan'];
			}
			return $a['inbound_internal'] <=> $b['inbound_internal'];
		} );

		return [
			'total_posts'  => count( $report ),
			'orphan_count' => count( array_filter( $report, fn( $r ) => $r['is_orphan'] ) ),
			'posts'        => $report,
		];
	}

	/**
	 * Find orphan posts (posts with zero inbound internal links).
	 *
	 * @return array Array of orphaned post data.
	 */
	public function get_orphan_posts(): array {
		$report = $this->get_link_report();
		return array_values( array_filter( $report['posts'], fn( $r ) => $r['is_orphan'] ) );
	}

	/**
	 * Count inbound internal links to a post from other published posts.
	 *
	 * Searches post_content of all other published posts for links
	 * pointing to this post's permalink or relative path.
	 *
	 * @param int $post_id The post ID to check.
	 * @return int Number of other posts linking to this post.
	 */
	private function count_inbound_links( int $post_id ): int {
		global $wpdb;

		$permalink = get_permalink( $post_id );
		$relative  = wp_parse_url( $permalink, PHP_URL_PATH );

		$count = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->posts}
			 WHERE post_status = 'publish'
			 AND ID != %d
			 AND (post_content LIKE %s OR post_content LIKE %s)",
			$post_id,
			'%' . $wpdb->esc_like( $permalink ) . '%',
			'%' . $wpdb->esc_like( $relative ) . '%'
		) );

		return $count;
	}

	/**
	 * Count outbound internal links in content.
	 *
	 * Counts all <a href> tags pointing to the current site
	 * (either absolute URLs matching home_url or root-relative paths).
	 *
	 * @param string $content The post content.
	 * @return int Number of outbound internal links.
	 */
	private function count_outbound_links( string $content ): int {
		$site_url = home_url();
		preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>/i', $content, $matches );
		$count = 0;
		foreach ( $matches[1] as $url ) {
			if ( strpos( $url, $site_url ) === 0 || strpos( $url, '/' ) === 0 ) {
				$count++;
			}
		}
		return $count;
	}

	/**
	 * Count external links in content.
	 *
	 * Counts all <a href> tags that begin with http/https and do not
	 * point to the current site.
	 *
	 * @param string $content The post content.
	 * @return int Number of external links.
	 */
	private function count_external_links( string $content ): int {
		$site_url = home_url();
		preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>/i', $content, $matches );
		$count = 0;
		foreach ( $matches[1] as $url ) {
			if ( strpos( $url, 'http' ) === 0 && strpos( $url, $site_url ) !== 0 ) {
				$count++;
			}
		}
		return $count;
	}

	// ====================================================================
	// HELPER METHODS
	// ====================================================================

	/**
	 * Get all existing link URLs in content.
	 *
	 * @param string $content The post content.
	 * @return array Array of href values found in the content.
	 */
	private function get_existing_links( string $content ): array {
		preg_match_all( '/<a\s[^>]*href=["\']([^"\']+)["\'][^>]*>/i', $content, $matches );
		return $matches[1] ?? [];
	}

	/**
	 * Split content text into sentences.
	 *
	 * Splits on sentence-ending punctuation followed by whitespace.
	 * Filters out very short fragments.
	 *
	 * @param string $text Plain text (HTML stripped).
	 * @return array Array of sentence strings.
	 */
	private function split_into_sentences( string $text ): array {
		// Normalize whitespace.
		$text = preg_replace( '/\s+/', ' ', trim( $text ) );
		// Split on sentence-ending punctuation.
		$sentences = preg_split( '/(?<=[.!?])\s+/', $text );
		return array_filter( $sentences, fn( $s ) => strlen( trim( $s ) ) > 20 );
	}

	/**
	 * Check if a position in a sentence already has a link in the raw content.
	 *
	 * Locates the sentence in the full HTML content and checks whether the
	 * character at the given offset falls inside an unclosed <a> tag.
	 *
	 * @param string $content  The full post HTML content.
	 * @param string $sentence The plain-text sentence to locate.
	 * @param int    $pos      The character offset within the sentence.
	 * @return bool True if the position is already inside an anchor tag.
	 */
	private function sentence_has_link_at_position( string $content, string $sentence, int $pos ): bool {
		// Find the sentence in the stripped content.
		$sent_pos = strpos( strip_tags( $content ), $sentence );
		if ( false === $sent_pos ) {
			return false;
		}

		// Check if there's an open <a> tag before this position in the raw content.
		$before     = substr( $content, 0, $sent_pos + $pos );
		$last_open  = strrpos( $before, '<a ' );
		$last_close = strrpos( $before, '</a>' );

		if ( false !== $last_open && ( false === $last_close || $last_close < $last_open ) ) {
			// We are inside an unclosed <a> tag.
			return true;
		}

		return false;
	}

	/**
	 * Expand anchor text to include surrounding words for better context.
	 *
	 * When a matched keyword is shorter than min_anchor_length words, this
	 * method appends subsequent words from the sentence until the minimum
	 * length is met.
	 *
	 * @param string $sentence The sentence containing the keyword.
	 * @param int    $pos      The character offset of the keyword in the sentence.
	 * @param int    $length   The character length of the keyword.
	 * @return string The expanded anchor text.
	 */
	private function expand_anchor( string $sentence, int $pos, int $length ): string {
		$words       = explode( ' ', $sentence );
		$current_pos = 0;
		$start_word  = 0;
		$end_word    = 0;

		foreach ( $words as $i => $word ) {
			$word_end = $current_pos + mb_strlen( $word );

			if ( $current_pos <= $pos && $pos < $word_end ) {
				$start_word = $i;
			}
			if ( $current_pos < $pos + $length && $pos + $length <= $word_end + 1 ) {
				$end_word = $i;
				break;
			}

			$current_pos = $word_end + 1; // +1 for the space separator.
		}

		// Expand end_word forward until we reach min_anchor_length.
		$min           = $this->config['min_anchor_length'];
		$current_count = $end_word - $start_word + 1;

		while ( $current_count < $min && $end_word < count( $words ) - 1 ) {
			$end_word++;
			$current_count++;
		}

		$expanded = array_slice( $words, $start_word, $end_word - $start_word + 1 );
		return implode( ' ', $expanded );
	}

	/**
	 * Remove all links from a post's content.
	 *
	 * Strips all <a> tags from the post, preserving their inner text.
	 * Useful for resetting a post before re-running the linker.
	 *
	 * @param int $post_id The post ID to clean.
	 * @return array Result including how many links were removed.
	 */
	public function remove_links( int $post_id ): array {
		$post = get_post( $post_id );
		if ( ! $post ) {
			return [ 'error' => 'Post not found' ];
		}

		$content = $post->post_content;

		// Strip all <a> tags but preserve inner text.
		$clean = preg_replace( '/<a\s[^>]*>(.*?)<\/a>/is', '$1', $content );

		$links_removed = substr_count( $content, '<a ' ) - substr_count( $clean, '<a ' );

		if ( $clean !== $content ) {
			wp_update_post( [
				'ID'           => $post_id,
				'post_content' => $clean,
			] );
		}

		return [
			'post_id'       => $post_id,
			'links_removed' => $links_removed,
		];
	}
}
