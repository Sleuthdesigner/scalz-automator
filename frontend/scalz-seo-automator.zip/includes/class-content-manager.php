<?php
/**
 * Content Manager
 *
 * Handles ACF field updates and AI-powered content generation
 * for WordPress pages and posts.
 *
 * @package ScalzSEOAutomator
 * @since   1.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Scalz_Content_Manager
 */
class Scalz_Content_Manager {

    /** @var Scalz_Integration_Manager */
    private Scalz_Integration_Manager $integration_manager;

    /**
     * Constructor.
     *
     * @param Scalz_Integration_Manager $integration_manager
     */
    public function __construct( Scalz_Integration_Manager $integration_manager ) {
        $this->integration_manager = $integration_manager;
    }

    // ─── ACF Field Update ─────────────────────────────────────────────────────

    /**
     * Update an ACF field value on a post/page.
     *
     * Supports wysiwyg and any other text-based field type.
     * Falls back to update_post_meta if ACF is not active.
     *
     * @param int    $page_id    Target post/page ID.
     * @param string $field_name ACF field name or key.
     * @param string $content    The content to store.
     * @param string $field_type ACF field type (wysiwyg, text, textarea, etc.).
     * @return array|WP_Error
     */
    public function update_acf_field( int $page_id, string $field_name, string $content, string $field_type = 'wysiwyg' ) {
        if ( ! get_post( $page_id ) ) {
            return new WP_Error( 'scalz_post_not_found', __( 'Post not found.', 'scalz-seo-automator' ), [ 'status' => 404 ] );
        }

        // For WYSIWYG fields allow full HTML; for other field types strip tags.
        if ( 'wysiwyg' === $field_type ) {
            $safe_content = wp_kses_post( $content );
        } else {
            $safe_content = sanitize_textarea_field( $content );
        }

        if ( function_exists( 'update_field' ) ) {
            // ACF is active — use its native update function.
            $updated = update_field( $field_name, $safe_content, $page_id );

            if ( false === $updated ) {
                // ACF returns false both on failure AND when the value hasn't changed.
                // Try to confirm by reading back the value.
                $current = get_field( $field_name, $page_id );
                if ( $current !== $safe_content ) {
                    return new WP_Error(
                        'scalz_acf_update_failed',
                        sprintf(
                            /* translators: %s: field name */
                            __( 'ACF update_field() returned false for field "%s". The field may not exist.', 'scalz-seo-automator' ),
                            $field_name
                        ),
                        [ 'status' => 500 ]
                    );
                }
            }
        } else {
            // ACF not active — fall back to raw post meta.
            update_post_meta( $page_id, $field_name, $safe_content );
        }

        return [
            'success'    => true,
            'page_id'    => $page_id,
            'field_name' => $field_name,
            'field_type' => $field_type,
            'updated'    => true,
        ];
    }

    // ─── AI Content Generation ────────────────────────────────────────────────

    /**
     * Generate content using AI from a prompt template, then save to an ACF field.
     *
     * Template variables (e.g. {title}, {location}) are replaced before sending
     * to the AI provider. The page title, site name, and current content are
     * automatically added to the variable pool.
     *
     * @param int    $page_id         Target post/page ID.
     * @param string $field_name      ACF field name to write result into.
     * @param string $prompt_template Prompt template string with {variable} placeholders.
     * @param array  $variables       Extra variables to inject into the template.
     * @return array|WP_Error
     */
    public function generate_and_save_content( int $page_id, string $field_name, string $prompt_template, array $variables = [] ) {
        $post = get_post( $page_id );

        if ( ! $post ) {
            return new WP_Error( 'scalz_post_not_found', __( 'Post not found.', 'scalz-seo-automator' ), [ 'status' => 404 ] );
        }

        // Build the base variable pool from the post.
        $base_variables = [
            'title'            => $post->post_title,
            'existing_content' => wp_strip_all_tags( $post->post_content ),
            'business_name'    => get_bloginfo( 'name' ),
            'focus_keyword'    => get_post_meta( $page_id, 'rank_math_focus_keyword', true ),
        ];

        // Merge caller-supplied variables (they override base variables).
        $all_variables = array_merge( $base_variables, $variables );

        // Sanitize variable values.
        $all_variables = array_map( 'sanitize_text_field', $all_variables );

        // Replace template variables.
        $prompt = Scalz_Integration_Manager::replace_template_variables( $prompt_template, $all_variables );

        // Call AI.
        $generated_content = $this->integration_manager->call_ai( $prompt, [] );

        if ( is_wp_error( $generated_content ) ) {
            return $generated_content;
        }

        // Save to ACF field.
        $save_result = $this->update_acf_field( $page_id, $field_name, $generated_content, 'wysiwyg' );

        if ( is_wp_error( $save_result ) ) {
            return $save_result;
        }

        return [
            'success'    => true,
            'page_id'    => $page_id,
            'field_name' => $field_name,
            'prompt'     => $prompt,
            'content'    => $generated_content,
        ];
    }

    // ─── Heading Normalization ─────────────────────────────────────────────────

    /**
     * Convert all h3–h6 heading tags in content to h2.
     *
     * Preserves the first h1 (assumed to be the page title) and
     * converts all lower-level headings to h2 for SEO consistency.
     *
     * @param string $content The HTML content to process.
     * @return string Modified HTML content.
     */
    public function normalize_headings( string $content ): string {
        // Replace opening h3-h6 tags (with any attributes) to h2.
        $content = preg_replace( '/<h[3-6](\s[^>]*)?>/', '<h2$1>', $content );
        // Replace closing h3-h6 tags.
        $content = preg_replace( '/<\/h[3-6]>/', '</h2>', $content );

        return $content;
    }
}
