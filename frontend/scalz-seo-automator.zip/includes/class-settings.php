<?php
/**
 * Settings Manager
 *
 * Registers the Scalz SEO Automator settings page in the WordPress admin,
 * handles option saving, API key regeneration, and provides helper methods
 * for reading stored settings throughout the plugin.
 *
 * @package ScalzSEOAutomator
 * @since   1.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Scalz_Settings
 */
class Scalz_Settings {

    /**
     * Register WordPress admin hooks.
     */
    public function register_hooks(): void {
        add_action( 'admin_menu',            [ $this, 'add_settings_page' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_assets' ] );
        add_action( 'admin_init',            [ $this, 'register_settings' ] );
        add_action( 'admin_post_scalz_seo_save_settings',    [ $this, 'handle_save_settings' ] );
        add_action( 'admin_post_scalz_seo_regenerate_key',   [ $this, 'handle_regenerate_key' ] );
        add_action( 'admin_post_scalz_seo_save_white_label', [ $this, 'handle_save_white_label' ] );
    }

    /**
     * Add the Scalz SEO Automator page under Settings menu.
     */
    public function add_settings_page(): void {
        $wl = get_option( 'scalz_seo_white_label', [] );
        $menu_title = ! empty( $wl['plugin_name'] ) ? $wl['plugin_name'] : 'SEO Automator';
        $menu_icon  = ! empty( $wl['menu_icon'] )   ? $wl['menu_icon']   : 'dashicons-chart-area';

        add_options_page(
            $menu_title,
            $menu_title,
            'manage_options',
            'scalz-seo-automator',
            [ $this, 'render_settings_page' ]
        );
    }

    /**
     * Enqueue admin CSS/JS on the plugin settings page.
     *
     * @param string $hook Current admin page hook suffix.
     */
    public function enqueue_admin_assets( string $hook ): void {
        if ( 'settings_page_scalz-seo-automator' !== $hook ) {
            return;
        }

        wp_enqueue_style(
            'scalz-seo-admin',
            SCALZ_SEO_PLUGIN_URL . 'admin/admin.css',
            [],
            SCALZ_SEO_VERSION
        );
    }

    /**
     * Register settings groups and sanitize callbacks via Settings API.
     */
    public function register_settings(): void {
        $settings = [
            'scalz_seo_ai_provider'             => 'sanitize_text_field',
            'scalz_seo_openai_api_key'           => 'sanitize_text_field',
            'scalz_seo_openai_model'             => 'sanitize_text_field',
            'scalz_seo_ai_temperature'           => [ $this, 'sanitize_temperature' ],
            'scalz_seo_prompt_page_title'        => 'sanitize_textarea_field',
            'scalz_seo_prompt_meta_description'  => 'sanitize_textarea_field',
            'scalz_seo_prompt_acf_content'       => 'sanitize_textarea_field',
            'scalz_seo_prompt_blog_title'        => 'sanitize_textarea_field',
            'scalz_seo_prompt_blog_content'      => 'sanitize_textarea_field',
            'scalz_seo_prompt_alt_tag'           => 'sanitize_textarea_field',
        ];

        foreach ( $settings as $option_name => $sanitize_callback ) {
            register_setting(
                'scalz_seo_settings_group',
                $option_name,
                [ 'sanitize_callback' => $sanitize_callback ]
            );
        }
    }

    /**
     * Sanitize temperature value (clamp to 0.0 – 2.0).
     *
     * @param mixed $value Raw input value.
     * @return float
     */
    public function sanitize_temperature( $value ): float {
        return min( 2.0, max( 0.0, (float) $value ) );
    }

    /**
     * Render the settings page via the admin template.
     */
    public function render_settings_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'You do not have sufficient permissions to access this page.', 'scalz-seo-automator' ) );
        }

        $template = SCALZ_SEO_PLUGIN_DIR . 'admin/settings-page.php';
        if ( file_exists( $template ) ) {
            include $template;
        }
    }

    /**
     * Handle the save settings form submission.
     */
    public function handle_save_settings(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'scalz-seo-automator' ) );
        }

        check_admin_referer( 'scalz_seo_save_settings_nonce', 'scalz_seo_nonce' );

        // AI Provider.
        $provider = sanitize_text_field( $_POST['scalz_seo_ai_provider'] ?? 'openai' );
        if ( in_array( $provider, [ 'openai', 'ai_engine' ], true ) ) {
            update_option( 'scalz_seo_ai_provider', $provider );
        }

        // OpenAI API Key.
        $api_key = sanitize_text_field( $_POST['scalz_seo_openai_api_key'] ?? '' );
        if ( ! empty( $api_key ) ) {
            update_option( 'scalz_seo_openai_api_key', $api_key );
        }

        // OpenAI Model.
        $model = sanitize_text_field( $_POST['scalz_seo_openai_model'] ?? 'gpt-4o' );
        if ( ! empty( $model ) ) {
            update_option( 'scalz_seo_openai_model', $model );
        }

        // Temperature.
        $temperature = min( 2.0, max( 0.0, (float) ( $_POST['scalz_seo_ai_temperature'] ?? 0.7 ) ) );
        update_option( 'scalz_seo_ai_temperature', $temperature );

        // Prompt templates.
        $prompt_fields = [
            'scalz_seo_prompt_page_title',
            'scalz_seo_prompt_meta_description',
            'scalz_seo_prompt_acf_content',
            'scalz_seo_prompt_blog_title',
            'scalz_seo_prompt_blog_content',
            'scalz_seo_prompt_alt_tag',
        ];

        foreach ( $prompt_fields as $field ) {
            if ( isset( $_POST[ $field ] ) ) {
                update_option( $field, sanitize_textarea_field( wp_unslash( $_POST[ $field ] ) ) );
            }
        }

        wp_safe_redirect(
            add_query_arg(
                [ 'page' => 'scalz-seo-automator', 'saved' => '1' ],
                admin_url( 'options-general.php' )
            )
        );
        exit;
    }

    /**
     * Handle API key regeneration form submission.
     */
    public function handle_regenerate_key(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'scalz-seo-automator' ) );
        }

        check_admin_referer( 'scalz_seo_regenerate_key_nonce', 'scalz_seo_nonce' );

        $new_key = wp_generate_password( 32, false );
        update_option( 'scalz_seo_api_key', $new_key );

        wp_safe_redirect(
            add_query_arg(
                [ 'page' => 'scalz-seo-automator', 'regenerated' => '1' ],
                admin_url( 'options-general.php' )
            )
        );
        exit;
    }

    /**
     * Handle the white-label settings form submission.
     */
    public function handle_save_white_label(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Insufficient permissions.', 'scalz-seo-automator' ) );
        }

        check_admin_referer( 'scalz_seo_save_white_label_nonce', 'scalz_seo_wl_nonce' );

        $wl = [
            'agency_name'   => sanitize_text_field( $_POST['wl_agency_name']   ?? 'SEO Automator' ),
            'agency_url'    => esc_url_raw( $_POST['wl_agency_url']             ?? '' ),
            'plugin_name'   => sanitize_text_field( $_POST['wl_plugin_name']   ?? 'SEO Automator' ),
            'menu_icon'     => sanitize_text_field( $_POST['wl_menu_icon']     ?? 'dashicons-chart-area' ),
            'hide_branding' => ! empty( $_POST['wl_hide_branding'] ),
        ];

        update_option( 'scalz_seo_white_label', $wl );

        wp_safe_redirect(
            add_query_arg(
                [ 'page' => 'scalz-seo-automator', 'tab' => 'white_label', 'saved' => '1' ],
                admin_url( 'options-general.php' )
            )
        );
        exit;
    }

    // ─── Accessors ────────────────────────────────────────────────────────────

    /**
     * Get the stored API key.
     *
     * @return string
     */
    public function get_api_key(): string {
        return (string) get_option( 'scalz_seo_api_key', '' );
    }

    /**
     * Get the configured AI provider slug.
     *
     * @return string 'openai' or 'ai_engine'.
     */
    public function get_ai_provider(): string {
        return (string) get_option( 'scalz_seo_ai_provider', 'openai' );
    }

    /**
     * Get the configured OpenAI model.
     *
     * @return string
     */
    public function get_openai_model(): string {
        return (string) get_option( 'scalz_seo_openai_model', 'gpt-4o' );
    }

    /**
     * Get all prompt templates as an associative array.
     *
     * @return array
     */
    public function get_prompt_templates(): array {
        return [
            'page_title'       => (string) get_option( 'scalz_seo_prompt_page_title', '' ),
            'meta_description' => (string) get_option( 'scalz_seo_prompt_meta_description', '' ),
            'acf_content'      => (string) get_option( 'scalz_seo_prompt_acf_content', '' ),
            'blog_title'       => (string) get_option( 'scalz_seo_prompt_blog_title', '' ),
            'blog_content'     => (string) get_option( 'scalz_seo_prompt_blog_content', '' ),
            'alt_tag'          => (string) get_option( 'scalz_seo_prompt_alt_tag', '' ),
        ];
    }
}
