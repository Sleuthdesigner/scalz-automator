<?php
/**
 * Schema Manager
 *
 * Generates and injects FAQ structured data (JSON-LD) into WordPress posts.
 * Supports both RankMath's schema API (when available) and a standalone
 * script-block injection method.
 *
 * @package ScalzSEOAutomator
 * @since   1.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Scalz_Schema_Manager
 */
class Scalz_Schema_Manager {

    /**
     * FAQ schema post meta key used to store JSON-LD data.
     */
    const FAQ_META_KEY = 'scalz_faq_schema';

    /**
     * Generate and inject FAQ schema for a post.
     *
     * First attempts to register the schema via RankMath's built-in schema
     * API. If RankMath is not available, stores the JSON-LD in post meta and
     * registers a wp_head hook to output the <script> block.
     *
     * @param int   $post_id Target post/page ID.
     * @param array $faqs    Array of ['question' => string, 'answer' => string].
     * @return array|WP_Error
     */
    public function inject_faq_schema( int $post_id, array $faqs ) {
        $post = get_post( $post_id );

        if ( ! $post ) {
            return new WP_Error(
                'scalz_post_not_found',
                __( 'Post not found.', 'scalz-seo-automator' ),
                [ 'status' => 404 ]
            );
        }

        if ( empty( $faqs ) ) {
            return new WP_Error(
                'scalz_empty_faqs',
                __( 'faqs array cannot be empty.', 'scalz-seo-automator' ),
                [ 'status' => 400 ]
            );
        }

        // Validate and sanitize FAQs.
        $sanitized_faqs = [];
        foreach ( $faqs as $index => $faq ) {
            $question = isset( $faq['question'] ) ? sanitize_text_field( $faq['question'] ) : '';
            $answer   = isset( $faq['answer'] )   ? wp_kses_post( $faq['answer'] )           : '';

            if ( empty( $question ) || empty( $answer ) ) {
                return new WP_Error(
                    'scalz_invalid_faq',
                    sprintf(
                        /* translators: %d: FAQ index (1-based) */
                        __( 'FAQ item at index %d is missing a question or answer.', 'scalz-seo-automator' ),
                        $index + 1
                    ),
                    [ 'status' => 400 ]
                );
            }

            $sanitized_faqs[] = [
                'question' => $question,
                'answer'   => $answer,
            ];
        }

        $schema = $this->generate_faq_schema( $sanitized_faqs );

        // ── RankMath Schema API ──────────────────────────────────────────────
        if ( $this->inject_via_rankmath( $post_id, $schema, $sanitized_faqs ) ) {
            return [
                'success'  => true,
                'post_id'  => $post_id,
                'method'   => 'rankmath',
                'faq_count' => count( $sanitized_faqs ),
                'schema'   => $schema,
            ];
        }

        // ── Fallback: store in post meta, output via wp_head ─────────────────
        $json_ld = wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT );
        update_post_meta( $post_id, self::FAQ_META_KEY, $json_ld );

        // Register the output hook if not already registered.
        if ( ! has_action( 'wp_head', [ $this, 'output_faq_schema' ] ) ) {
            add_action( 'wp_head', [ $this, 'output_faq_schema' ] );
        }

        return [
            'success'  => true,
            'post_id'  => $post_id,
            'method'   => 'post_meta',
            'faq_count' => count( $sanitized_faqs ),
            'schema'   => $schema,
        ];
    }

    /**
     * Build the https://schema.org/FAQPage JSON-LD array.
     *
     * @param array $faqs Sanitized array of ['question', 'answer'] pairs.
     * @return array The schema.org FAQPage array.
     */
    public function generate_faq_schema( array $faqs ): array {
        return [
            '@context'   => 'https://schema.org',
            '@type'      => 'FAQPage',
            'mainEntity' => array_map(
                function( array $faq ): array {
                    return [
                        '@type' => 'Question',
                        'name'  => $faq['question'],
                        'acceptedAnswer' => [
                            '@type' => 'Answer',
                            'text'  => $faq['answer'],
                        ],
                    ];
                },
                $faqs
            ),
        ];
    }

    /**
     * Attempt to inject the FAQ schema via RankMath's custom schema storage.
     *
     * RankMath stores its schemas as serialized JSON in the
     * rank_math_rich_snippet post meta key. This method appends (or replaces)
     * a FAQPage schema entry.
     *
     * @param int   $post_id        Post ID.
     * @param array $schema         Full schema.org array.
     * @param array $sanitized_faqs Sanitized FAQ pairs.
     * @return bool True if injection was handled by RankMath, false otherwise.
     */
    private function inject_via_rankmath( int $post_id, array $schema, array $sanitized_faqs ): bool {
        if ( ! class_exists( 'RankMath' ) && ! function_exists( 'rank_math' ) ) {
            return false;
        }

        // RankMath PRO stores schemas as JSON in a dedicated meta key.
        // The meta key rank_math_schema_<id> stores individual schema blocks.
        // For compatibility, we also set the legacy snippet type.

        // Set the legacy rich snippet type to FAQ.
        update_post_meta( $post_id, 'rank_math_rich_snippet', 'faqpage' );

        // Build RankMath-compatible FAQ items.
        $rm_faqs = [];
        foreach ( $sanitized_faqs as $i => $faq ) {
            $rm_faqs[ 'faq-question-' . ( $i + 1 ) ] = [
                'question' => $faq['question'],
                'answer'   => $faq['answer'],
            ];
        }

        // Store FAQ items in RankMath's format.
        update_post_meta( $post_id, 'rank_math_snippet_faqs', $rm_faqs );

        // Also write the raw JSON-LD schema block for RankMath PRO.
        $schema_id  = 'scalz-faq-' . $post_id;
        $rm_schema  = $schema;
        $rm_schema['metadata'] = [
            'title'       => 'FAQ - Scalz SEO Automator',
            'type'        => 'template',
            'shortcode'   => '',
            'isPrimary'   => true,
            'reviewScore' => false,
        ];

        update_post_meta( $post_id, 'rank_math_schema_' . $schema_id, $rm_schema );

        return true;
    }

    /**
     * wp_head action: output the FAQ schema JSON-LD <script> block.
     *
     * Reads from post meta and outputs a <script type="application/ld+json">
     * block for the current singular post/page.
     */
    public function output_faq_schema(): void {
        if ( ! is_singular() ) {
            return;
        }

        $post_id  = get_the_ID();
        $json_ld  = get_post_meta( $post_id, self::FAQ_META_KEY, true );

        if ( empty( $json_ld ) ) {
            return;
        }

        echo '<script type="application/ld+json">' . "\n";
        // $json_ld is already encoded; we've stored it sanitized via wp_json_encode.
        echo $json_ld; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped — data is pre-sanitized JSON.
        echo "\n" . '</script>' . "\n";
    }
}
