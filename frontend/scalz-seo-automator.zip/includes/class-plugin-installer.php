<?php
/**
 * Plugin Installer
 *
 * Downloads, installs, activates, and optionally licenses
 * third-party WordPress plugins from a .zip URL.
 *
 * Supports common license activation patterns:
 *   - Easy Digital Downloads (EDD) Software Licensing
 *   - WooCommerce Subscriptions / Extensions
 *   - Freemius SDK
 *   - Generic EDD-SL REST endpoint
 *
 * @package ScalzSEOAutomator
 * @since   1.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Scalz_Plugin_Installer
 */
class Scalz_Plugin_Installer {

    /**
     * Download, install, and activate a plugin from a zip URL.
     *
     * After activation, optionally attempts to register a license key
     * using common activation patterns.
     *
     * @param string      $zip_url     Publicly accessible URL to the plugin .zip file.
     * @param string|null $license_key Optional license key to activate after install.
     * @return array|WP_Error
     */
    public function install_and_activate( string $zip_url, ?string $license_key = null ) {
        // ── Step 1: Load WordPress upgrader classes ──────────────────────────
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/misc.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';

        // Ensure filesystem access.
        $credentials = request_filesystem_credentials( '', '', false, false, null );
        if ( ! WP_Filesystem( $credentials ) ) {
            return new WP_Error(
                'scalz_filesystem_error',
                __( 'Could not initialize the WordPress filesystem. Check file permissions.', 'scalz-seo-automator' ),
                [ 'status' => 500 ]
            );
        }

        // ── Step 2: Install the plugin via Plugin_Upgrader ───────────────────
        $skin     = new WP_Ajax_Upgrader_Skin();
        $upgrader = new Plugin_Upgrader( $skin );

        $result = $upgrader->install( $zip_url );

        if ( is_wp_error( $result ) ) {
            return new WP_Error(
                'scalz_install_failed',
                sprintf(
                    /* translators: %s: error message */
                    __( 'Plugin install failed: %s', 'scalz-seo-automator' ),
                    $result->get_error_message()
                ),
                [ 'status' => 500 ]
            );
        }

        if ( false === $result ) {
            $skin_errors = $skin->get_errors();
            $error_msg   = is_wp_error( $skin_errors ) ? $skin_errors->get_error_message() : __( 'Unknown install error.', 'scalz-seo-automator' );
            return new WP_Error( 'scalz_install_failed', $error_msg, [ 'status' => 500 ] );
        }

        // ── Step 3: Find the installed plugin file ───────────────────────────
        $plugin_file = $this->find_installed_plugin( $upgrader );

        if ( is_wp_error( $plugin_file ) ) {
            return $plugin_file;
        }

        // ── Step 4: Activate the plugin ──────────────────────────────────────
        if ( ! is_plugin_active( $plugin_file ) ) {
            $activated = activate_plugin( $plugin_file );

            if ( is_wp_error( $activated ) ) {
                return new WP_Error(
                    'scalz_activation_failed',
                    sprintf(
                        /* translators: %s: error message */
                        __( 'Plugin installed but activation failed: %s', 'scalz-seo-automator' ),
                        $activated->get_error_message()
                    ),
                    [ 'status' => 500 ]
                );
            }
        }

        $response = [
            'success'      => true,
            'plugin_file'  => $plugin_file,
            'activated'    => true,
            'license_activated' => false,
            'license_message'   => '',
        ];

        // ── Step 5: Attempt license activation ──────────────────────────────
        if ( ! empty( $license_key ) ) {
            $license_result = $this->activate_license( $plugin_file, sanitize_text_field( $license_key ) );
            $response['license_activated'] = ! is_wp_error( $license_result );
            $response['license_message']   = is_wp_error( $license_result )
                ? $license_result->get_error_message()
                : ( is_array( $license_result ) && isset( $license_result['message'] ) ? $license_result['message'] : __( 'License activated.', 'scalz-seo-automator' ) );
        }

        return $response;
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    /**
     * Determine the plugin file path after installation.
     *
     * @param Plugin_Upgrader $upgrader The upgrader instance used for install.
     * @return string|WP_Error Plugin file relative path (folder/plugin.php).
     */
    private function find_installed_plugin( Plugin_Upgrader $upgrader ) {
        // Plugin_Upgrader stores result in ->new_plugin_data after install.
        if ( ! empty( $upgrader->new_plugin_data ) && isset( $upgrader->new_plugin_data['PluginFile'] ) ) {
            return $upgrader->new_plugin_data['PluginFile'];
        }

        // Fallback: scan the plugins directory for newly added folder.
        $plugins_dir = WP_PLUGIN_DIR;
        $all_plugins = get_plugins();

        // Look for the plugin file in the directory that was just installed.
        // Plugin_Upgrader puts result info in result['destination_name'].
        if ( ! empty( $upgrader->result['destination_name'] ) ) {
            $folder = $upgrader->result['destination_name'];

            foreach ( $all_plugins as $file => $data ) {
                if ( strpos( $file, $folder . '/' ) === 0 ) {
                    return $file;
                }
            }
        }

        return new WP_Error(
            'scalz_plugin_file_not_found',
            __( 'Plugin was installed but the main plugin file could not be located.', 'scalz-seo-automator' ),
            [ 'status' => 500 ]
        );
    }

    /**
     * Attempt license activation for common license systems.
     *
     * Tries the following patterns in order:
     * 1. EDD Software Licensing filter/action hook.
     * 2. Generic EDD-SL REST endpoint auto-detection.
     * 3. Freemius SDK activation.
     * 4. WooCommerce Subscriptions activation endpoint.
     *
     * @param string $plugin_file Relative plugin file path (folder/file.php).
     * @param string $license_key License key to activate.
     * @return array|WP_Error
     */
    private function activate_license( string $plugin_file, string $license_key ) {
        $plugin_slug = dirname( $plugin_file );

        // ── Method 1: EDD Software Licensing action hook ─────────────────────
        if ( has_action( 'edd_sl_license_' . $plugin_slug . '_activate' ) ) {
            do_action( 'edd_sl_license_' . $plugin_slug . '_activate', $license_key );
            return [ 'method' => 'edd_hook', 'message' => __( 'License activation hook triggered.', 'scalz-seo-automator' ) ];
        }

        // ── Method 2: EDD-SL API endpoint auto-detection ─────────────────────
        // Many premium plugins store their EDD store URL as an option.
        $edd_result = $this->try_edd_license_activation( $plugin_slug, $license_key );
        if ( ! is_wp_error( $edd_result ) ) {
            return $edd_result;
        }

        // ── Method 3: Freemius ────────────────────────────────────────────────
        if ( function_exists( 'freemius' ) || class_exists( 'Freemius' ) ) {
            $fs_result = $this->try_freemius_activation( $plugin_slug, $license_key );
            if ( ! is_wp_error( $fs_result ) ) {
                return $fs_result;
            }
        }

        // ── Method 4: Store in a generic license option ──────────────────────
        // Many plugins check an option named like `{slug}_license_key`.
        $option_key = str_replace( '-', '_', $plugin_slug ) . '_license_key';
        update_option( $option_key, $license_key );

        // Also try underscore variant.
        $option_key_2 = $plugin_slug . '_license';
        update_option( $option_key_2, $license_key );

        return [
            'method'  => 'options_fallback',
            'message' => sprintf(
                /* translators: %s: option key */
                __( 'License key stored in option "%s". Some plugins may require manual activation in their settings page.', 'scalz-seo-automator' ),
                $option_key
            ),
        ];
    }

    /**
     * Attempt to activate via EDD Software Licensing API.
     *
     * Looks for known option keys where the plugin stores its EDD store URL.
     *
     * @param string $plugin_slug Plugin directory slug.
     * @param string $license_key License key.
     * @return array|WP_Error
     */
    private function try_edd_license_activation( string $plugin_slug, string $license_key ) {
        // Common EDD SL store URL option naming patterns.
        $url_option_candidates = [
            str_replace( '-', '_', $plugin_slug ) . '_store_url',
            str_replace( '-', '_', $plugin_slug ) . '_edd_url',
            $plugin_slug . '_store_url',
        ];

        $store_url = '';
        foreach ( $url_option_candidates as $opt ) {
            $val = get_option( $opt, '' );
            if ( ! empty( $val ) && filter_var( $val, FILTER_VALIDATE_URL ) ) {
                $store_url = $val;
                break;
            }
        }

        if ( empty( $store_url ) ) {
            return new WP_Error( 'scalz_no_edd_store_url', 'No EDD store URL found.' );
        }

        $api_params = [
            'edd_action'  => 'activate_license',
            'license'     => $license_key,
            'item_name'   => urlencode( $plugin_slug ),
            'url'         => home_url(),
        ];

        $response = wp_remote_get(
            add_query_arg( $api_params, $store_url ),
            [ 'timeout' => 30, 'sslverify' => true ]
        );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $license_data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( isset( $license_data['license'] ) && 'valid' === $license_data['license'] ) {
            // Store license status.
            $status_key = str_replace( '-', '_', $plugin_slug ) . '_license_status';
            update_option( $status_key, 'valid' );
            return [ 'method' => 'edd_api', 'message' => __( 'EDD license activated successfully.', 'scalz-seo-automator' ) ];
        }

        return new WP_Error(
            'scalz_edd_license_failed',
            sprintf(
                /* translators: %s: license status from EDD */
                __( 'EDD license activation returned status: %s', 'scalz-seo-automator' ),
                $license_data['license'] ?? 'unknown'
            )
        );
    }

    /**
     * Attempt to activate via Freemius SDK.
     *
     * @param string $plugin_slug Plugin directory slug.
     * @param string $license_key License key.
     * @return array|WP_Error
     */
    private function try_freemius_activation( string $plugin_slug, string $license_key ) {
        // Freemius uses a global instance per plugin.
        $fs_global_function = str_replace( '-', '_', $plugin_slug );

        if ( function_exists( $fs_global_function ) ) {
            try {
                /** @var Freemius $fs */
                $fs = call_user_func( $fs_global_function );

                if ( is_object( $fs ) && method_exists( $fs, 'activate_migrated_license' ) ) {
                    $result = $fs->activate_migrated_license( $license_key );
                    if ( $result ) {
                        return [ 'method' => 'freemius', 'message' => __( 'Freemius license activated.', 'scalz-seo-automator' ) ];
                    }
                }
            } catch ( \Throwable $e ) {
                return new WP_Error( 'scalz_freemius_error', $e->getMessage() );
            }
        }

        return new WP_Error( 'scalz_freemius_not_available', 'Freemius global function not found.' );
    }
}
