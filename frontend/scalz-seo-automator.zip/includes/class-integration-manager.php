<?php
/**
 * Integration Manager
 *
 * Handles all third-party integrations:
 * - OpenAI (direct API)
 * - AI Engine by Meow Apps
 * - RankMath SEO
 * - LinkWhisper internal linking
 * - Template variable replacement system
 *
 * @package ScalzSEOAutomator
 * @since   1.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Scalz_Integration_Manager
 */
class Scalz_Integration_Manager {

    // ─── Active Integrations ──────────────────────────────────────────────────

    /**
     * Return a map of active third-party integrations.
     *
     * @return array Associative array of integration => bool.
     */
    public function get_active_integrations(): array {
        return [
            'rankmath'    => $this->is_rankmath_active(),
            'acf'         => $this->is_acf_active(),
            'link_whisper' => $this->is_link_whisper_active(),
            'ai_engine'   => $this->is_ai_engine_active(),
            'openai'      => ! empty( get_option( 'scalz_seo_openai_api_key' ) ),
        ];
    }

    /**
     * Check whether RankMath SEO is active.
     *
     * @return bool
     */
    public function is_rankmath_active(): bool {
        return class_exists( 'RankMath' ) || function_exists( 'rank_math' );
    }

    /**
     * Check whether Advanced Custom Fields (free or Pro) is active.
     *
     * @return bool
     */
    public function is_acf_active(): bool {
        return function_exists( 'get_field' ) && function_exists( 'update_field' );
    }

    /**
     * Check whether LinkWhisper is active.
     *
     * @return bool
     */
    public function is_link_whisper_active(): bool {
        return class_exists( 'wpil_base' ) || class_exists( 'Wpil_Base' ) || function_exists( 'wpil_get_post_links' );
    }

    /**
     * Check whether AI Engine (Meow Apps) is active.
     *
     * @return bool
     */
    public function is_ai_engine_active(): bool {
        return class_exists( 'Meow_MWAI_Core' ) || function_exists( 'mwai_get_options' ) || has_filter( 'mwai_ai_query' );
    }

    // ─── AI Dispatch ──────────────────────────────────────────────────────────

    /**
     * Call the configured AI provider with a prompt.
     *
     * Reads provider/config from wp_options unless $config overrides are supplied.
     *
     * @param string $prompt  The full prompt text.
     * @param array  $config  Optional overrides: provider, api_key, model, temperature.
     * @return string|WP_Error AI-generated text on success, WP_Error on failure.
     */
    public function call_ai( string $prompt, array $config = [] ) {
        // Build effective config from stored options + caller overrides.
        $effective = wp_parse_args( $config, [
            'provider'    => get_option( 'scalz_seo_ai_provider', 'openai' ),
            'api_key'     => get_option( 'scalz_seo_openai_api_key', '' ),
            'model'       => get_option( 'scalz_seo_openai_model', 'gpt-4o' ),
            'temperature' => (float) get_option( 'scalz_seo_ai_temperature', 0.7 ),
        ] );

        if ( 'ai_engine' === $effective['provider'] ) {
            return $this->call_ai_engine( $prompt, $effective );
        }

        // Default: OpenAI.
        return $this->call_openai( $prompt, $effective );
    }

    /**
     * Call OpenAI Chat Completions API directly.
     *
     * @param string $prompt The user prompt.
     * @param array  $config Must include api_key; optionally model, temperature.
     * @return string|WP_Error
     */
    public function call_openai( string $prompt, array $config ) {
        $api_key = $config['api_key'] ?? '';

        if ( empty( $api_key ) ) {
            return new WP_Error(
                'scalz_no_openai_key',
                __( 'OpenAI API key is not configured. Set it in Settings > Scalz SEO Automator or via POST /ai/configure.', 'scalz-seo-automator' ),
                [ 'status' => 500 ]
            );
        }

        $body = [
            'model'    => $config['model'] ?? 'gpt-4o',
            'messages' => [
                [
                    'role'    => 'system',
                    'content' => 'You are an expert SEO content writer for local service businesses. Always follow the instructions exactly and output only what is asked for.',
                ],
                [
                    'role'    => 'user',
                    'content' => $prompt,
                ],
            ],
            'temperature' => isset( $config['temperature'] ) ? (float) $config['temperature'] : 0.7,
        ];

        $response = wp_remote_post(
            'https://api.openai.com/v1/chat/completions',
            [
                'headers' => [
                    'Authorization' => 'Bearer ' . $api_key,
                    'Content-Type'  => 'application/json',
                ],
                'body'    => wp_json_encode( $body ),
                'timeout' => 120,
            ]
        );

        if ( is_wp_error( $response ) ) {
            return new WP_Error(
                'scalz_openai_http_error',
                sprintf(
                    /* translators: %s: HTTP error message */
                    __( 'OpenAI HTTP request failed: %s', 'scalz-seo-automator' ),
                    $response->get_error_message()
                ),
                [ 'status' => 502 ]
            );
        }

        $status_code = wp_remote_retrieve_response_code( $response );
        $body_raw    = wp_remote_retrieve_body( $response );
        $data        = json_decode( $body_raw, true );

        if ( $status_code !== 200 ) {
            $error_message = $data['error']['message'] ?? $body_raw;
            return new WP_Error(
                'scalz_openai_api_error',
                sprintf(
                    /* translators: 1: HTTP status, 2: error message */
                    __( 'OpenAI API returned %1$d: %2$s', 'scalz-seo-automator' ),
                    $status_code,
                    $error_message
                ),
                [ 'status' => 502 ]
            );
        }

        if ( empty( $data['choices'][0]['message']['content'] ) ) {
            return new WP_Error(
                'scalz_openai_empty_response',
                __( 'OpenAI returned an empty response.', 'scalz-seo-automator' ),
                [ 'status' => 502 ]
            );
        }

        return trim( $data['choices'][0]['message']['content'] );
    }

    /**
     * Call AI Engine (Meow Apps) for completions.
     *
     * Tries the PHP filter hook first; falls back to the plugin's own REST API
     * if the filter isn't available.
     *
     * @param string $prompt The user prompt.
     * @param array  $config Optional model/temperature overrides.
     * @return string|WP_Error
     */
    public function call_ai_engine( string $prompt, array $config ) {
        if ( ! $this->is_ai_engine_active() ) {
            return new WP_Error(
                'scalz_ai_engine_not_active',
                __( 'AI Engine plugin is not active.', 'scalz-seo-automator' ),
                [ 'status' => 500 ]
            );
        }

        // ── Method 1: Direct PHP filter (preferred, no HTTP overhead) ──────────
        if ( has_filter( 'mwai_ai_query' ) ) {
            $query_args = [
                'prompt'      => $prompt,
                'model'       => $config['model'] ?? 'gpt-4o',
                'temperature' => $config['temperature'] ?? 0.7,
                'maxTokens'   => 2000,
            ];

            $result = apply_filters( 'mwai_ai_query', null, $query_args );

            if ( is_wp_error( $result ) ) {
                return $result;
            }

            if ( isset( $result['text'] ) ) {
                return trim( $result['text'] );
            }

            if ( is_string( $result ) && ! empty( $result ) ) {
                return trim( $result );
            }
        }

        // ── Method 2: AI Engine REST endpoint ─────────────────────────────────
        $rest_url = get_rest_url( null, 'mwai/v1/completions' );

        $response = wp_remote_post( $rest_url, [
            'headers' => [
                'Content-Type' => 'application/json',
                'X-WP-Nonce'   => wp_create_nonce( 'wp_rest' ),
            ],
            'body'    => wp_json_encode( [
                'prompt'      => $prompt,
                'model'       => $config['model'] ?? 'gpt-4o',
                'temperature' => $config['temperature'] ?? 0.7,
                'maxTokens'   => 2000,
                'stream'      => false,
            ] ),
            'timeout' => 120,
        ] );

        if ( is_wp_error( $response ) ) {
            return new WP_Error(
                'scalz_ai_engine_http_error',
                sprintf(
                    /* translators: %s: HTTP error message */
                    __( 'AI Engine HTTP request failed: %s', 'scalz-seo-automator' ),
                    $response->get_error_message()
                ),
                [ 'status' => 502 ]
            );
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( ! empty( $body['text'] ) ) {
            return trim( $body['text'] );
        }

        if ( ! empty( $body['result'] ) ) {
            return trim( $body['result'] );
        }

        return new WP_Error(
            'scalz_ai_engine_empty_response',
            __( 'AI Engine returned an empty or unrecognized response.', 'scalz-seo-automator' ),
            [ 'status' => 502 ]
        );
    }

    // ─── AI Configuration ─────────────────────────────────────────────────────

    /**
     * Store AI provider configuration in wp_options.
     *
     * @param string      $provider    'openai' or 'ai_engine'.
     * @param string|null $api_key     OpenAI API key (required when provider is openai).
     * @param string|null $model       Model name (e.g. gpt-4o).
     * @param float       $temperature Sampling temperature 0–2.
     * @return array|WP_Error
     */
    public function configure_ai( string $provider, ?string $api_key = null, ?string $model = null, float $temperature = 0.7 ) {
        $allowed_providers = [ 'openai', 'ai_engine' ];

        if ( ! in_array( $provider, $allowed_providers, true ) ) {
            return new WP_Error(
                'scalz_invalid_provider',
                sprintf(
                    /* translators: %s: comma-separated list of allowed values */
                    __( 'Provider must be one of: %s', 'scalz-seo-automator' ),
                    implode( ', ', $allowed_providers )
                ),
                [ 'status' => 400 ]
            );
        }

        if ( 'openai' === $provider && empty( $api_key ) ) {
            return new WP_Error(
                'scalz_missing_api_key',
                __( 'api_key is required when provider is "openai".', 'scalz-seo-automator' ),
                [ 'status' => 400 ]
            );
        }

        update_option( 'scalz_seo_ai_provider', sanitize_text_field( $provider ) );

        if ( ! empty( $api_key ) ) {
            update_option( 'scalz_seo_openai_api_key', sanitize_text_field( $api_key ) );
        }

        if ( ! empty( $model ) ) {
            update_option( 'scalz_seo_openai_model', sanitize_text_field( $model ) );
        }

        update_option( 'scalz_seo_ai_temperature', min( 2, max( 0, $temperature ) ) );

        return [
            'success'     => true,
            'provider'    => $provider,
            'model'       => get_option( 'scalz_seo_openai_model', 'gpt-4o' ),
            'temperature' => get_option( 'scalz_seo_ai_temperature', 0.7 ),
            'api_key_set' => ! empty( get_option( 'scalz_seo_openai_api_key' ) ),
        ];
    }

    // ─── RankMath Integration ─────────────────────────────────────────────────

    /**
     * Set RankMath focus keyword and return SEO score/suggestions.
     *
     * @param int    $post_id       The post/page ID.
     * @param string $focus_keyword The target focus keyword.
     * @return array|WP_Error
     */
    public function rankmath_optimize( int $post_id, string $focus_keyword ) {
        if ( ! get_post( $post_id ) ) {
            return new WP_Error( 'scalz_post_not_found', __( 'Post not found.', 'scalz-seo-automator' ), [ 'status' => 404 ] );
        }

        // Store focus keyword.
        $this->set_focus_keyword( $post_id, $focus_keyword );

        // Retrieve current SEO score if RankMath has already scored it.
        $seo_score = $this->get_seo_score( $post_id );

        $result = [
            'success'       => true,
            'post_id'       => $post_id,
            'focus_keyword' => $focus_keyword,
            'seo_score'     => $seo_score,
            'rankmath_active' => $this->is_rankmath_active(),
        ];

        // If RankMath is active, try to trigger a fresh analysis.
        if ( $this->is_rankmath_active() && class_exists( 'RankMath\Post\Post' ) ) {
            try {
                // RankMath recalculates score on post save — force a silent update.
                wp_update_post( [ 'ID' => $post_id ] );
                $result['seo_score'] = $this->get_seo_score( $post_id );
            } catch ( \Throwable $e ) {
                $result['warning'] = __( 'Could not trigger RankMath re-analysis.', 'scalz-seo-automator' );
            }
        }

        return $result;
    }

    /**
     * Write the RankMath focus keyword post meta.
     *
     * @param int    $post_id Post ID.
     * @param string $keyword Focus keyword.
     */
    public function set_focus_keyword( int $post_id, string $keyword ): void {
        update_post_meta( $post_id, 'rank_math_focus_keyword', sanitize_text_field( $keyword ) );
    }

    /**
     * Read the RankMath SEO score post meta.
     *
     * @param int $post_id Post ID.
     * @return int|string The SEO score or an empty string if not available.
     */
    public function get_seo_score( int $post_id ) {
        return get_post_meta( $post_id, 'rank_math_seo_score', true );
    }

    // ─── LinkWhisper Integration ──────────────────────────────────────────────

    /**
     * Trigger LinkWhisper's auto-link suggestion and application for given posts.
     *
     * @param array $post_ids Optional list of post IDs. Empty means all posts.
     * @return array|WP_Error
     */
    public function run_link_whisper( array $post_ids = [] ) {
        if ( ! $this->is_link_whisper_active() ) {
            return new WP_Error(
                'scalz_link_whisper_not_active',
                __( 'LinkWhisper is not active on this site.', 'scalz-seo-automator' ),
                [ 'status' => 404 ]
            );
        }

        // If no post IDs specified, get all published posts and pages.
        if ( empty( $post_ids ) ) {
            $posts = get_posts( [
                'post_type'      => [ 'post', 'page' ],
                'post_status'    => 'publish',
                'posts_per_page' => -1,
                'fields'         => 'ids',
            ] );
            $post_ids = $posts;
        }

        $processed = [];
        $failed    = [];

        foreach ( $post_ids as $pid ) {
            $pid = (int) $pid;

            try {
                // LinkWhisper 3.x+ uses static methods and action hooks.
                // Attempt several known integration points.

                // Method 1: wpil_run_link_report action (premium hook).
                if ( has_action( 'wpil_run_link_report' ) ) {
                    do_action( 'wpil_run_link_report', $pid );
                    $processed[] = $pid;
                    continue;
                }

                // Method 2: Direct class call if available.
                if ( class_exists( 'Wpil_Report' ) && method_exists( 'Wpil_Report', 'get_link_data' ) ) {
                    \Wpil_Report::get_link_data( $pid );
                    $processed[] = $pid;
                    continue;
                }

                // Method 3: Apply suggestions stored in LinkWhisper DB tables.
                if ( class_exists( 'Wpil_Suggestion' ) && method_exists( 'Wpil_Suggestion', 'apply_suggestion' ) ) {
                    $suggestions = \Wpil_Suggestion::get_suggestions_for_post( $pid );
                    if ( ! empty( $suggestions ) ) {
                        foreach ( $suggestions as $suggestion ) {
                            \Wpil_Suggestion::apply_suggestion( $suggestion );
                        }
                    }
                    $processed[] = $pid;
                    continue;
                }

                // Fallback: note that LinkWhisper is present but API method not found.
                $failed[] = [
                    'post_id' => $pid,
                    'reason'  => 'LinkWhisper is active but no supported integration method was found. Upgrade LinkWhisper or trigger linking manually.',
                ];

            } catch ( \Throwable $e ) {
                $failed[] = [
                    'post_id' => $pid,
                    'reason'  => $e->getMessage(),
                ];
            }
        }

        return [
            'success'   => count( $failed ) === 0,
            'processed' => $processed,
            'failed'    => $failed,
            'total'     => count( $post_ids ),
        ];
    }

    // ─── Template Variable System ─────────────────────────────────────────────

    /**
     * Replace all {variable} placeholders in a template string.
     *
     * Supported variables:
     *   {title}            – Page/post title
     *   {location}         – Full location (City, State)
     *   {city}             – City name
     *   {state}            – Full state name
     *   {state_abbr}       – State abbreviation
     *   {business_name}    – Business / site name
     *   {service}          – Service name
     *   {niche}            – Business niche
     *   {phone}            – Business phone
     *   {address}          – Business address
     *   {existing_content} – Current page content
     *   {focus_keyword}    – Target SEO keyword
     *   {count}            – Numeric count
     *   {existing_titles}  – Pipe-separated list of existing post titles
     *
     * Any {key} in the template that does not match a supplied variable key
     * is left as-is.
     *
     * @param string $template  The template string.
     * @param array  $variables Key-value pairs for substitution.
     * @return string
     */
    public static function replace_template_variables( string $template, array $variables ): string {
        $search  = [];
        $replace = [];

        foreach ( $variables as $key => $value ) {
            $search[]  = '{' . $key . '}';
            $replace[] = (string) $value;
        }

        return str_replace( $search, $replace, $template );
    }
}
