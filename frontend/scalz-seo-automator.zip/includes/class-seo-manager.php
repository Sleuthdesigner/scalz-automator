<?php
/**
 * SEO Manager
 *
 * Handles SEO operations: page title updates, meta descriptions,
 * RankMath integration, and image alt tag generation.
 *
 * @package ScalzSEOAutomator
 * @since   1.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Scalz_Seo_Manager
 */
class Scalz_Seo_Manager {

    /** @var Scalz_Integration_Manager */
    private Scalz_Integration_Manager $integration_manager;

    /**
     * Constructor.
     *
     * @param Scalz_Integration_Manager $integration_manager
     */
    public function __construct( Scalz_Integration_Manager $integration_manager ) {
        $this->integration_manager = $integration_manager;
    }

    // ─── Page Titles ─────────────────────────────────────────────────────────

    /**
     * Bulk-update WordPress page/post titles.
     *
     * @param array $pages Array of ['page_id' => int, 'new_title' => string].
     * @return array|WP_Error Summary of updated/failed pages.
     */
    public function update_page_titles( array $pages ) {
        $results = [
            'updated' => [],
            'failed'  => [],
        ];

        foreach ( $pages as $page ) {
            $page_id   = isset( $page['page_id'] ) ? (int) $page['page_id'] : 0;
            $new_title = isset( $page['new_title'] ) ? sanitize_text_field( $page['new_title'] ) : '';

            if ( ! $page_id || ! $new_title ) {
                $results['failed'][] = [
                    'page_id' => $page_id,
                    'reason'  => 'Missing page_id or new_title.',
                ];
                continue;
            }

            // Verify post exists.
            if ( ! get_post( $page_id ) ) {
                $results['failed'][] = [
                    'page_id' => $page_id,
                    'reason'  => 'Post not found.',
                ];
                continue;
            }

            $update_id = wp_update_post( [
                'ID'         => $page_id,
                'post_title' => $new_title,
                'post_name'  => '', // Let WordPress regenerate slug only if needed.
            ], true );

            if ( is_wp_error( $update_id ) ) {
                $results['failed'][] = [
                    'page_id' => $page_id,
                    'reason'  => $update_id->get_error_message(),
                ];
            } else {
                $results['updated'][] = [
                    'page_id'   => $page_id,
                    'new_title' => $new_title,
                ];
            }
        }

        return $results;
    }

    // ─── Meta Descriptions ────────────────────────────────────────────────────

    /**
     * Set RankMath meta description for each provided page.
     *
     * @param array $pages Array of ['page_id' => int, 'meta_description' => string].
     * @return array Summary of updated/failed.
     */
    public function update_meta_descriptions( array $pages ): array {
        $results = [
            'updated' => [],
            'failed'  => [],
        ];

        foreach ( $pages as $page ) {
            $page_id     = isset( $page['page_id'] ) ? (int) $page['page_id'] : 0;
            $description = isset( $page['meta_description'] ) ? wp_strip_all_tags( $page['meta_description'] ) : '';

            if ( ! $page_id ) {
                $results['failed'][] = [ 'page_id' => $page_id, 'reason' => 'Invalid page_id.' ];
                continue;
            }

            if ( ! get_post( $page_id ) ) {
                $results['failed'][] = [ 'page_id' => $page_id, 'reason' => 'Post not found.' ];
                continue;
            }

            $this->set_meta_description( $page_id, $description );

            $results['updated'][] = [
                'page_id'     => $page_id,
                'description' => $description,
            ];
        }

        return $results;
    }

    /**
     * Auto-generate meta descriptions using AI then store via RankMath.
     *
     * @param array|null $ai_config Optional AI configuration overrides.
     * @return array|WP_Error
     */
    public function auto_generate_meta_descriptions( ?array $ai_config = [] ) {
        $posts = get_posts( [
            'post_type'      => [ 'page', 'post' ],
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
        ] );

        if ( empty( $posts ) ) {
            return new WP_Error( 'scalz_no_posts', __( 'No published posts or pages found.', 'scalz-seo-automator' ), [ 'status' => 404 ] );
        }

        $results = [
            'generated' => [],
            'failed'    => [],
        ];

        $template = get_option( 'scalz_seo_prompt_meta_description',
            'Write a concise, compelling 155-character SEO meta description for a page titled "{title}" about {service} in {location}. Focus on the primary benefit and include a call to action. Output only the meta description text, no quotes.' );

        foreach ( $posts as $post_id ) {
            $post = get_post( $post_id );

            $variables = [
                'title'   => $post->post_title,
                'service' => get_bloginfo( 'name' ),
                'location' => '',
            ];

            $prompt = Scalz_Integration_Manager::replace_template_variables( $template, $variables );

            $description = $this->integration_manager->call_ai( $prompt, $ai_config ?? [] );

            if ( is_wp_error( $description ) ) {
                $results['failed'][] = [
                    'page_id' => $post_id,
                    'reason'  => $description->get_error_message(),
                ];
                continue;
            }

            // Trim to 160 characters just in case.
            $description = mb_substr( trim( $description ), 0, 160 );
            $this->set_meta_description( $post_id, $description );

            $results['generated'][] = [
                'page_id'     => $post_id,
                'title'       => $post->post_title,
                'description' => $description,
            ];
        }

        return $results;
    }

    /**
     * Store meta description via RankMath post meta.
     *
     * @param int    $post_id     The post/page ID.
     * @param string $description The meta description text.
     */
    public function set_meta_description( int $post_id, string $description ): void {
        // RankMath stores meta description in this post meta key.
        update_post_meta( $post_id, 'rank_math_description', sanitize_text_field( $description ) );

        // Also support Yoast SEO as a fallback.
        update_post_meta( $post_id, '_yoast_wpseo_metadesc', sanitize_text_field( $description ) );
    }

    // ─── Alt Tags ─────────────────────────────────────────────────────────────

    /**
     * Scan posts for images missing alt tags and generate them via AI.
     *
     * @param int|null $page_id Optional single post/page ID. If null, processes all.
     * @return array|WP_Error
     */
    public function update_alt_tags( ?int $page_id = null ) {
        if ( $page_id ) {
            $posts = [ get_post( $page_id ) ];
            if ( empty( $posts[0] ) ) {
                return new WP_Error( 'scalz_post_not_found', __( 'Post not found.', 'scalz-seo-automator' ), [ 'status' => 404 ] );
            }
        } else {
            $posts = get_posts( [
                'post_type'      => [ 'page', 'post' ],
                'post_status'    => 'publish',
                'posts_per_page' => -1,
            ] );
        }

        $results = [
            'updated' => [],
            'skipped' => [],
            'failed'  => [],
        ];

        $alt_template = get_option( 'scalz_seo_prompt_alt_tag',
            'Write a concise, descriptive SEO alt tag for an image on a page titled "{title}". The alt tag should describe what would be in the image naturally. Output only the alt tag text, no quotes, max 125 characters.' );

        foreach ( $posts as $post ) {
            if ( ! $post ) {
                continue;
            }

            $post_id      = (int) $post->ID;
            $post_title   = $post->post_title;
            $post_content = $post->post_content;

            // ── 1. Featured image alt tag ────────────────────────────────────
            $thumbnail_id = get_post_thumbnail_id( $post_id );
            if ( $thumbnail_id ) {
                $existing_alt = get_post_meta( $thumbnail_id, '_wp_attachment_image_alt', true );
                if ( empty( $existing_alt ) ) {
                    $prompt  = Scalz_Integration_Manager::replace_template_variables( $alt_template, [ 'title' => $post_title ] );
                    $new_alt = $this->integration_manager->call_ai( $prompt, [] );

                    if ( ! is_wp_error( $new_alt ) ) {
                        $new_alt = mb_substr( trim( $new_alt ), 0, 125 );
                        update_post_meta( $thumbnail_id, '_wp_attachment_image_alt', sanitize_text_field( $new_alt ) );
                        $results['updated'][] = [
                            'post_id'      => $post_id,
                            'type'         => 'featured_image',
                            'attachment_id' => $thumbnail_id,
                            'alt'          => $new_alt,
                        ];
                    } else {
                        $results['failed'][] = [
                            'post_id' => $post_id,
                            'type'    => 'featured_image',
                            'reason'  => $new_alt->get_error_message(),
                        ];
                    }
                } else {
                    $results['skipped'][] = [ 'post_id' => $post_id, 'type' => 'featured_image', 'reason' => 'Already has alt tag.' ];
                }
            }

            // ── 2. Inline content images ─────────────────────────────────────
            if ( empty( $post_content ) ) {
                continue;
            }

            // Parse <img> tags from content.
            $dom = new DOMDocument();
            libxml_use_internal_errors( true );
            $dom->loadHTML( mb_convert_encoding( $post_content, 'HTML-ENTITIES', 'UTF-8' ) );
            libxml_clear_errors();

            $images  = $dom->getElementsByTagName( 'img' );
            $changed = false;

            /** @var DOMElement $img */
            foreach ( $images as $img ) {
                $alt = $img->getAttribute( 'alt' );

                if ( ! empty( trim( $alt ) ) ) {
                    $results['skipped'][] = [
                        'post_id' => $post_id,
                        'type'    => 'inline_image',
                        'src'     => $img->getAttribute( 'src' ),
                        'reason'  => 'Already has alt tag.',
                    ];
                    continue;
                }

                $prompt  = Scalz_Integration_Manager::replace_template_variables( $alt_template, [ 'title' => $post_title ] );
                $new_alt = $this->integration_manager->call_ai( $prompt, [] );

                if ( is_wp_error( $new_alt ) ) {
                    $results['failed'][] = [
                        'post_id' => $post_id,
                        'type'    => 'inline_image',
                        'src'     => $img->getAttribute( 'src' ),
                        'reason'  => $new_alt->get_error_message(),
                    ];
                    continue;
                }

                $new_alt = mb_substr( trim( $new_alt ), 0, 125 );
                $img->setAttribute( 'alt', esc_attr( $new_alt ) );
                $changed = true;

                $results['updated'][] = [
                    'post_id' => $post_id,
                    'type'    => 'inline_image',
                    'src'     => $img->getAttribute( 'src' ),
                    'alt'     => $new_alt,
                ];
            }

            // Save modified post content if any images were updated.
            if ( $changed ) {
                // Extract just the body content, not the full HTML document.
                $body         = $dom->getElementsByTagName( 'body' )->item( 0 );
                $new_content  = '';
                foreach ( $body->childNodes as $node ) {
                    $new_content .= $dom->saveHTML( $node );
                }

                wp_update_post( [
                    'ID'           => $post_id,
                    'post_content' => $new_content,
                ] );
            }
        }

        return $results;
    }
}
