<?php
/**
 * Blog Manager
 *
 * Handles sitemap parsing, AI-powered blog title generation,
 * blog post creation, and heading normalization.
 *
 * @package ScalzSEOAutomator
 * @since   1.0.0
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Scalz_Blog_Manager
 */
class Scalz_Blog_Manager {

    /** @var Scalz_Integration_Manager */
    private Scalz_Integration_Manager $integration_manager;

    /**
     * Constructor.
     *
     * @param Scalz_Integration_Manager $integration_manager
     */
    public function __construct( Scalz_Integration_Manager $integration_manager ) {
        $this->integration_manager = $integration_manager;
    }

    // ─── Sitemap Parsing ──────────────────────────────────────────────────────

    /**
     * Fetch and parse the /post-sitemap.xml file.
     *
     * Returns an array of post titles and URLs as found in the sitemap.
     * Falls back to a WordPress-generated list if the sitemap cannot be fetched.
     *
     * @return array|WP_Error
     */
    public function get_sitemap_posts() {
        $sitemap_url = trailingslashit( get_site_url() ) . 'post-sitemap.xml';

        $response = wp_remote_get( $sitemap_url, [
            'timeout'   => 30,
            'sslverify' => apply_filters( 'https_ssl_verify', false ),
        ] );

        if ( is_wp_error( $response ) ) {
            // Fallback: build list from WordPress query.
            return $this->get_sitemap_posts_from_db();
        }

        $status = wp_remote_retrieve_response_code( $response );
        if ( $status !== 200 ) {
            return $this->get_sitemap_posts_from_db();
        }

        $body = wp_remote_retrieve_body( $response );

        if ( empty( $body ) ) {
            return $this->get_sitemap_posts_from_db();
        }

        return $this->parse_sitemap_xml( $body );
    }

    /**
     * Parse a sitemap XML string and extract loc + title pairs.
     *
     * @param string $xml Raw XML content of the sitemap.
     * @return array Array of ['title' => string, 'url' => string].
     */
    private function parse_sitemap_xml( string $xml ): array {
        $posts = [];

        libxml_use_internal_errors( true );
        $doc = new SimpleXMLElement( $xml );
        libxml_clear_errors();

        // Register Google's image/news namespaces if present.
        $namespaces = $doc->getNamespaces( true );

        foreach ( $doc->url as $url_node ) {
            $loc = (string) $url_node->loc;

            // Attempt to get <news:title> or <image:title> if present.
            $title = '';

            if ( isset( $namespaces['news'] ) ) {
                $news = $url_node->children( $namespaces['news'] );
                if ( isset( $news->news->title ) ) {
                    $title = (string) $news->news->title;
                }
            }

            // Fallback: derive title from URL slug.
            if ( empty( $title ) ) {
                // Get the post from the URL.
                $post_id = url_to_postid( $loc );
                if ( $post_id ) {
                    $title = get_the_title( $post_id );
                }
            }

            if ( empty( $title ) ) {
                // Last resort: humanize the URL slug.
                $slug  = basename( untrailingslashit( $loc ) );
                $title = ucwords( str_replace( [ '-', '_' ], ' ', $slug ) );
            }

            $posts[] = [
                'title' => sanitize_text_field( $title ),
                'url'   => esc_url_raw( $loc ),
            ];
        }

        return [
            'count' => count( $posts ),
            'posts' => $posts,
        ];
    }

    /**
     * Fallback: build post list from WordPress database query.
     *
     * @return array
     */
    private function get_sitemap_posts_from_db(): array {
        $wp_posts = get_posts( [
            'post_type'      => 'post',
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ] );

        $posts = array_map( function( $post ) {
            return [
                'title' => $post->post_title,
                'url'   => get_permalink( $post->ID ),
            ];
        }, $wp_posts );

        return [
            'count'  => count( $posts ),
            'posts'  => $posts,
            'source' => 'database_fallback',
        ];
    }

    // ─── Blog Title Generation ────────────────────────────────────────────────

    /**
     * Use AI to generate unique blog title ideas.
     *
     * Passes existing titles to the AI so it avoids duplicates.
     *
     * @param int    $count           Number of titles to generate.
     * @param string $niche           Business/industry niche.
     * @param string $location        Target location (city, state).
     * @param array  $existing_titles Array of existing titles to avoid.
     * @return array|WP_Error
     */
    public function generate_blog_titles( int $count = 5, string $niche = '', string $location = '', array $existing_titles = [] ) {
        $template = get_option( 'scalz_seo_prompt_blog_title',
            'Generate {count} unique, SEO-optimized blog post title ideas for a {niche} business in {location}. ' .
            'The titles should attract local customers, target long-tail keywords, and be suitable for a service business blog. ' .
            'Do NOT use any of these existing titles: {existing_titles}. ' .
            'Return ONLY a JSON array of title strings, no explanation. Example: ["Title 1", "Title 2"]' );

        $existing_titles_str = empty( $existing_titles )
            ? 'none'
            : implode( ' | ', array_map( 'sanitize_text_field', array_slice( $existing_titles, 0, 50 ) ) );

        $variables = [
            'count'           => (string) $count,
            'niche'           => sanitize_text_field( $niche ),
            'location'        => sanitize_text_field( $location ),
            'existing_titles' => $existing_titles_str,
        ];

        $prompt = Scalz_Integration_Manager::replace_template_variables( $template, $variables );

        $ai_response = $this->integration_manager->call_ai( $prompt, [] );

        if ( is_wp_error( $ai_response ) ) {
            return $ai_response;
        }

        // Parse JSON array from AI response.
        $titles = $this->extract_json_array( $ai_response );

        if ( is_wp_error( $titles ) ) {
            return $titles;
        }

        // Sanitize titles.
        $titles = array_map( 'sanitize_text_field', $titles );

        return [
            'count'  => count( $titles ),
            'titles' => $titles,
        ];
    }

    /**
     * Extract a JSON array from an AI text response.
     *
     * The AI may wrap the JSON in markdown code fences or add prose.
     * This method strips common wrappers before decoding.
     *
     * @param string $response Raw AI response.
     * @return array|WP_Error
     */
    private function extract_json_array( string $response ) {
        // Strip markdown code fences.
        $response = preg_replace( '/```(?:json)?\s*/i', '', $response );
        $response = trim( str_replace( '```', '', $response ) );

        // Find first [ and last ].
        $start = strpos( $response, '[' );
        $end   = strrpos( $response, ']' );

        if ( $start === false || $end === false ) {
            return new WP_Error(
                'scalz_json_parse_error',
                __( 'AI response did not contain a valid JSON array.', 'scalz-seo-automator' ),
                [ 'status' => 500 ]
            );
        }

        $json   = substr( $response, $start, $end - $start + 1 );
        $titles = json_decode( $json, true );

        if ( json_last_error() !== JSON_ERROR_NONE || ! is_array( $titles ) ) {
            return new WP_Error(
                'scalz_json_parse_error',
                sprintf(
                    /* translators: %s: JSON error message */
                    __( 'Failed to parse AI JSON response: %s', 'scalz-seo-automator' ),
                    json_last_error_msg()
                ),
                [ 'status' => 500 ]
            );
        }

        return $titles;
    }

    // ─── Blog Post Creation ───────────────────────────────────────────────────

    /**
     * Create a new WordPress blog post from the supplied content.
     *
     * All h3–h6 headings in the content are normalized to h2 before saving.
     *
     * @param string $title      Post title.
     * @param string $content    Post HTML content.
     * @param array  $categories Array of category names or IDs to assign.
     * @param array  $tags       Array of tag names or IDs to assign.
     * @return array|WP_Error
     */
    public function create_blog_post( string $title, string $content, array $categories = [], array $tags = [] ) {
        if ( empty( $title ) ) {
            return new WP_Error( 'scalz_empty_title', __( 'Blog post title cannot be empty.', 'scalz-seo-automator' ), [ 'status' => 400 ] );
        }

        // Normalize headings — convert h3-h6 to h2.
        $content = $this->normalize_headings( $content );

        // Resolve categories (create if they don't exist).
        $category_ids = $this->resolve_terms( $categories, 'category' );

        // Resolve tags.
        $tag_ids = $this->resolve_terms( $tags, 'post_tag' );

        $post_data = [
            'post_title'    => sanitize_text_field( $title ),
            'post_content'  => wp_kses_post( $content ),
            'post_status'   => 'publish',
            'post_type'     => 'post',
            'post_category' => $category_ids,
            'tags_input'    => $tag_ids,
        ];

        $post_id = wp_insert_post( $post_data, true );

        if ( is_wp_error( $post_id ) ) {
            return $post_id;
        }

        return [
            'success'    => true,
            'post_id'    => $post_id,
            'title'      => $title,
            'permalink'  => get_permalink( $post_id ),
            'categories' => $category_ids,
            'tags'       => $tag_ids,
        ];
    }

    /**
     * Normalize headings in a blog post (converts h3–h6 to h2).
     *
     * @param int $post_id Target post ID.
     * @return array|WP_Error
     */
    public function fix_post_headings( int $post_id ) {
        $post = get_post( $post_id );

        if ( ! $post ) {
            return new WP_Error( 'scalz_post_not_found', __( 'Post not found.', 'scalz-seo-automator' ), [ 'status' => 404 ] );
        }

        $original_content = $post->post_content;
        $new_content      = $this->normalize_headings( $original_content );

        if ( $new_content === $original_content ) {
            return [
                'success'  => true,
                'post_id'  => $post_id,
                'changed'  => false,
                'message'  => __( 'No heading changes needed.', 'scalz-seo-automator' ),
            ];
        }

        $updated = wp_update_post( [
            'ID'           => $post_id,
            'post_content' => $new_content,
        ], true );

        if ( is_wp_error( $updated ) ) {
            return $updated;
        }

        return [
            'success' => true,
            'post_id' => $post_id,
            'changed' => true,
            'message' => __( 'Headings normalized to H2.', 'scalz-seo-automator' ),
        ];
    }

    // ─── Helpers ──────────────────────────────────────────────────────────────

    /**
     * Convert all h3–h6 heading tags to h2.
     *
     * @param string $content HTML string.
     * @return string
     */
    private function normalize_headings( string $content ): string {
        $content = preg_replace( '/<h([3-6])(\s[^>]*)?>/', '<h2$2>', $content );
        $content = preg_replace( '/<\/h[3-6]>/', '</h2>', $content );
        return $content;
    }

    /**
     * Resolve term names/IDs to an array of integer IDs.
     *
     * Creates terms that don't exist yet.
     *
     * @param array  $terms    Array of term names (strings) or IDs (integers).
     * @param string $taxonomy WordPress taxonomy slug.
     * @return array Array of integer term IDs.
     */
    private function resolve_terms( array $terms, string $taxonomy ): array {
        $ids = [];

        foreach ( $terms as $term ) {
            if ( is_numeric( $term ) ) {
                $ids[] = (int) $term;
                continue;
            }

            $term_name = sanitize_text_field( (string) $term );
            $existing  = get_term_by( 'name', $term_name, $taxonomy );

            if ( $existing ) {
                $ids[] = $existing->term_id;
            } else {
                $new_term = wp_insert_term( $term_name, $taxonomy );
                if ( ! is_wp_error( $new_term ) ) {
                    $ids[] = $new_term['term_id'];
                }
            }
        }

        return $ids;
    }
}
