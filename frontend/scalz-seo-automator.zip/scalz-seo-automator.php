<?php
/**
 * Plugin Name:       SEO Automator
 * Plugin URI:        https://example.com
 * Description:       White-label WordPress SEO automation plugin. Exposes REST API endpoints for SEO tasks including meta descriptions, ACF content, blog creation, internal linking, alt tags, FAQ schema, and more.
 * Version:           1.1.0
 * Requires at least: 5.8
 * Requires PHP:      7.4
 * Author:            SEO Automator
 * Author URI:        https://example.com
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       scalz-seo-automator
 * Domain Path:       /languages
 *
 * @package ScalzSEOAutomator
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// ─── Plugin Constants ────────────────────────────────────────────────────────

define( 'SCALZ_SEO_VERSION',     '1.1.0' );
define( 'SCALZ_SEO_PLUGIN_FILE', __FILE__ );
define( 'SCALZ_SEO_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'SCALZ_SEO_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'SCALZ_SEO_API_NS',      'scalz/v1' );

// ─── Autoloader ─────────────────────────────────────────────────────────────

/**
 * Simple autoloader for plugin classes.
 *
 * Maps class names of the form Scalz_Foo_Bar to
 * includes/class-foo-bar.php.
 *
 * @param string $class_name The fully-qualified class name.
 */
function scalz_seo_autoloader( string $class_name ): void {
    if ( strpos( $class_name, 'Scalz_' ) !== 0 ) {
        return;
    }

    $filename = strtolower( str_replace( [ 'Scalz_', '_' ], [ '', '-' ], $class_name ) );
    $filepath = SCALZ_SEO_PLUGIN_DIR . 'includes/class-' . $filename . '.php';

    if ( file_exists( $filepath ) ) {
        require_once $filepath;
    }
}
spl_autoload_register( 'scalz_seo_autoloader' );

// ─── Bootstrap ───────────────────────────────────────────────────────────────

/**
 * Main plugin bootstrap function.
 *
 * Instantiates every manager class and registers WordPress hooks.
 * Called on the 'plugins_loaded' hook so all dependencies are available.
 */
function scalz_seo_automator_init(): void {
    // Load text domain for i18n.
    load_plugin_textdomain(
        'scalz-seo-automator',
        false,
        dirname( plugin_basename( __FILE__ ) ) . '/languages'
    );

    // Instantiate core managers.
    $integration_manager = new Scalz_Integration_Manager();
    $seo_manager         = new Scalz_Seo_Manager( $integration_manager );
    $content_manager     = new Scalz_Content_Manager( $integration_manager );
    $blog_manager        = new Scalz_Blog_Manager( $integration_manager );
    $schema_manager      = new Scalz_Schema_Manager();
    $plugin_installer    = new Scalz_Plugin_Installer();
    $internal_linker     = new Scalz_Internal_Linker();
    $settings            = new Scalz_Settings();

    // Boot REST API layer.
    $api_endpoints = new Scalz_Api_Endpoints(
        $seo_manager,
        $content_manager,
        $blog_manager,
        $integration_manager,
        $schema_manager,
        $plugin_installer,
        $settings
    );
    $api_endpoints->set_internal_linker( $internal_linker );
    $api_endpoints->register_hooks();

    // Boot admin settings page.
    $settings->register_hooks();
}
add_action( 'plugins_loaded', 'scalz_seo_automator_init' );

// ─── Activation / Deactivation / Uninstall ──────────────────────────────────

/**
 * Plugin activation hook.
 *
 * Generates a default API key if one does not already exist.
 */
function scalz_seo_automator_activate(): void {
    if ( ! get_option( 'scalz_seo_api_key' ) ) {
        update_option( 'scalz_seo_api_key', wp_generate_password( 32, false ) );
    }

    if ( ! get_option( 'scalz_seo_white_label' ) ) {
        update_option( 'scalz_seo_white_label', [
            'agency_name'    => 'SEO Automator',
            'agency_url'     => '',
            'plugin_name'    => 'SEO Automator',
            'menu_icon'      => 'dashicons-chart-area',
            'hide_branding'  => false,
        ]);
    }

    // Set plugin version in options.
    update_option( 'scalz_seo_version', SCALZ_SEO_VERSION );

    // Flush rewrite rules so REST routes are registered.
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'scalz_seo_automator_activate' );

/**
 * Plugin deactivation hook.
 */
function scalz_seo_automator_deactivate(): void {
    flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'scalz_seo_automator_deactivate' );

/**
 * Plugin uninstall hook.
 *
 * Removes all plugin options from the database.
 * Called as a static file include by WordPress on uninstall.
 */
function scalz_seo_automator_uninstall(): void {
    $options_to_delete = [
        'scalz_seo_api_key',
        'scalz_seo_version',
        'scalz_seo_ai_provider',
        'scalz_seo_openai_api_key',
        'scalz_seo_openai_model',
        'scalz_seo_ai_temperature',
        'scalz_seo_prompt_page_title',
        'scalz_seo_prompt_meta_description',
        'scalz_seo_prompt_acf_content',
        'scalz_seo_prompt_blog_title',
        'scalz_seo_prompt_blog_content',
        'scalz_seo_prompt_alt_tag',
        'scalz_seo_white_label',
        'scalz_internal_linker_config',
        'scalz_autolink_rules',
        'scalz_link_index_stats',
    ];

    foreach ( $options_to_delete as $option ) {
        delete_option( $option );
    }
}
register_uninstall_hook( __FILE__, 'scalz_seo_automator_uninstall' );
